/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Project, Course, BlogPost } from './types';

export const projects: Project[] = [
  {
    id: 'snake',
    title: 'AI Snake Game',
    tag: 'OpenCV',
    desc: 'Gesture-controlled game using hand-tracking through webcam.',
    longDesc: 'A futuristic recreation of the classic Snake Game that utilizes OpenCV and MediaPipe for hand posture classification and landmark detection. Players direct the snake dynamically using intuitive real-time finger gestures captured on their camera.',
    tech: ['Python', 'OpenCV', 'MediaPipe', 'NumPy', 'Pygame'],
    github: 'https://github.com/muskan/ai-snake-game',
    demoId: 'snake',
  },
  {
    id: 'calculator',
    title: 'Advanced Calculator',
    tag: 'Python',
    desc: 'Modern GUI with arithmetic and complex math functions.',
    longDesc: 'A comprehensive, multi-functional desktop calculator powered by a customized expression parsing engine. Supports advanced scientific functions, algebraic formulations, trigonometric expressions, and history logging.',
    tech: ['Python', 'Tkinter', 'Math Library', 'RegEx', 'Custom Parser'],
    github: 'https://github.com/muskan/advanced-calculator',
    demoId: 'calculator',
  },
  {
    id: 'neural-optimizer',
    title: 'AI Training Playground',
    tag: 'Machine Learning',
    desc: 'Interactive hyperparameter optimizer playground with live training charts.',
    longDesc: 'A live interactive sandbox simulating the training of neural network topologies. Allows developers to tune hyperparameters like learning rate, epochs, and batch size to analyze convergence curves, and inspect custom Confusion Matrices.',
    tech: ['Python', 'SciPy', 'Scikit-Learn', 'NumPy', 'Data Visualization'],
    github: 'https://github.com/muskan/ai-training-optimizer',
    demoId: 'nnPlayground',
  }
];

export const courses: Course[] = [
  {
    id: 'ds_algo',
    title: 'Data Structures & Algorithms',
    code: 'BSc-CS-301',
    score: 'A+',
    desc: 'Foundational study of algorithm complexity, sorting, and linear and non-linear memory structures.',
    syllabus: [
      'Asymptotic notation (Big O, Omega, Theta)',
      'Balanced search trees (AVL Trees, Red-Black Trees)',
      'Graph traversals (BFS, DFS) & Dijkstra Shortest Path',
      'Dynamic programming (Knapsack, Fibonacci memoization)'
    ],
    sampleCodeTitle: 'dijkstra_routing.py',
    sampleCode: `def dijkstra(graph, start):
    distances = {node: float('inf') for node in graph}
    distances[start] = 0
    visited = set()
    
    while len(visited) < len(graph):
        current = min((n for n in graph if n not in visited), key=lambda x: distances[x])
        visited.add(current)
        
        for neighbor, weight in graph[current].items():
            new_dist = distances[current] + weight
            if new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
    return distances

network = {
    'Router_A': {'Router_B': 4, 'Router_C': 2},
    'Router_B': {'Router_A': 4, 'Router_C': 1, 'Router_D': 5},
    'Router_C': {'Router_A': 2, 'Router_B': 1, 'Router_D': 8},
    'Router_D': {'Router_B': 5, 'Router_C': 8}
}
print(dijkstra(network, 'Router_A'))`,
    sampleCodeOutput: [
      "[RUNNING] python dijkstra_routing.py",
      "[INITIALIZE] Heap queue initialized...",
      "[TRAVERSE] Visiting Router_A: distance = 0",
      "[TRAVERSE] Relaxing neighbors: Router_B(4), Router_C(2)",
      "[TRAVERSE] Visiting Router_C: distance = 2",
      "[TRAVERSE] Relaxing neighbors: Router_B(3), Router_D(10)",
      "[TRAVERSE] Visiting Router_B: distance = 3",
      "[TRAVERSE] Relaxing neighbors: Router_D(8)",
      "[TRAVERSE] Visiting Router_D: distance = 8",
      "[SUCCESS] Shortest distances mapped:",
      "  { 'Router_A': 0,",
      "    'Router_B': 3,",
      "    'Router_C': 2,",
      "    'Router_D': 8 }"
    ]
  },
  {
    id: 'dbms_sql',
    title: 'Database Management Systems',
    code: 'BSc-CS-302',
    score: 'A',
    desc: 'Relational algebra, schema designs, normalization (1NF-BCNF) and transactional safety (ACID).',
    syllabus: [
      'Relational algebra and calculus operators',
      'Functional dependencies and normalization (1NF, 2NF, 3NF, BCNF)',
      'Transaction states and ACID constraints',
      'SQL querying, indexing structures (B+ Trees), and JOIN optimizations'
    ],
    sampleCodeTitle: 'analyze_normalization.sql',
    sampleCode: `/* Check for dependency violations in raw student table */
SELECT student_id, student_name, count(distinct college_dept) 
FROM raw_grades_sheet
GROUP BY student_id, student_name
HAVING count(distinct college_dept) > 1;

/* Create normalized tables (2NF -> 3NF decomposition) */
CREATE TABLE Student (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES Department(dept_id)
);`,
    sampleCodeOutput: [
      "[SQL EXECUTE] Initializing PostgreSQL parser on database 'igmmv_college'...",
      "[ANALYSIS] Running schema analyzer...",
      " - Scanning 12,500 tuple records for functional dependencies...",
      " - [PASS] student_id -> student_name (No violations detected)",
      " - [VIOLATION] course_code -> instructor_office (Partial dependency found!)",
      "[DECOMPOSE] Creating normalized tables Student & Department...",
      "[SUCCESS] Schema successfully upgraded to 3NF! B+ Tree indexes populated."
    ]
  },
  {
    id: 'ai_automation',
    title: 'Python AI & Computer Vision',
    code: 'BSc-CS-402',
    score: 'A+',
    desc: 'Practical software interfaces combining raw mathematics, video streams, and classification arrays.',
    syllabus: [
      'OpenCV frame grabbing, masking, and colorspace matrices (RGB, HSV)',
      'MediaPipe skeletal graphs (21 landmark coordinate vectors for hands)',
      'Posture mapping algorithms using cosine similarity',
      'Interactive desktop UI building with Tkinter and custom canvases'
    ],
    sampleCodeTitle: 'gesture_angle_estimator.py',
    sampleCode: `import numpy as np

def calculate_angle(a, b, c):
    # Vector vectors of points a, b, c
    ba = np.array(a) - np.array(b)
    bc = np.array(c) - np.array(b)
    
    cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc))
    angle = np.arccos(np.clip(cosine_angle, -1.0, 1.0))
    return np.degrees(angle)

# Coordinate representation for Thumb, Wrist, and Index base
thumb_tip = [22, 53]
wrist = [45, 72]
index_base = [50, 52]

print("Joint Angle:", calculate_angle(thumb_tip, wrist, index_base))` ,
    sampleCodeOutput: [
      "[RUNNING] python gesture_angle_estimator.py",
      "[MATH] Importing numpy library and loading floating vectors...",
      "[VECTOR] Point A: [22, 53] | Point B: [45, 72] | Point C: [50, 52]",
      "[VECTOR] Vector BA: [-23, -19] | Vector BC: [5, -20]",
      "[COMPUTE] Dot product: 265.0 | Norms: 29.83, 20.61",
      "[SUCCESS] Calculated Gesture Angle: 64.53 degrees",
      "[CLASSIFY] Gesture aligned with category: 'OK_SIGN' (Confidence: 97.4%)"
    ]
  },
  {
    id: 'comp_networks',
    title: 'Computer Networks',
    code: 'BSc-CS-403',
    score: 'A',
    desc: 'ISO-OSI seven layer framework, routing matrices, and sliding window protocols.',
    syllabus: [
      'Physical & Data Link Layers: Error correction (CRC), sliding window (ARQ)',
      'Network Layer: IPv4/IPv6 addressing, classless routing, RIP/OSPF protocols',
      'Transport Layer: TCP handshaking, congestion windows, UDP packets',
      'Application Layer: Domain Name Resolution (DNS), HTTP/HTTPS, and Socket APIs'
    ],
    sampleCodeTitle: 'socket_listener.py',
    sampleCode: `import socket

def spawn_server(host='0.0.0.0', port=3000):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    server.listen(1)
    print(f"Server listening on {host}:{port}")
    
    conn, addr = server.accept()
    print(f"Connection ingress from: {addr}")
    conn.send(b"HTTP/1.1 200 OK\\r\\nContent-Type: text/plain\\r\\n\\r\\nCONNECTION SUCCESSFUL")
    conn.close()`,
    sampleCodeOutput: [
      "[RUNNING] python socket_listener.py",
      "[NET] Creating TCP stream socket...",
      "[BIND] Port 3000 mapped successfully on host 0.0.0.0",
      "[LISTEN] Server listening... Queue buffer size: 1",
      "[INGRESS] Client detected! IP: 127.0.0.1, Port: 49152",
      "[HANDSHAKE] Syn-Ack sequence validated. Connection ESTABLISHED.",
      "[WRITE] Transmitting 200 OK buffer... 48 bytes written.",
      "[CLOSE] Socket stream closed. Sandbox socket operational."
    ]
  }
];

export const blogPosts: BlogPost[] = [
  {
    id: 'mp_landmarks',
    title: 'Demystifying MediaPipe Hand Landmark Indexes',
    date: 'Jul 10, 2026',
    tag: 'Computer Vision',
    readTime: '4 min read',
    summary: 'A developer guide mapping out the 21 unique 3D coordinate nodes generated for fingers and wrists, and implementing geometric logic to classify gestures.',
    content: `When working with computer vision on a webcam, developers often get overwhelmed by raw coordinates. **MediaPipe Hands** returns exactly 21 landmarks. 

Each finger has 4 joints (MCP, PIP, DIP, Tip). By extracting coordinates:
- Landmark 0 is the Wrist.
- Landmarks 4, 8, 12, 16, 20 are finger Tips.

To classify a 'Fist' versus an 'Open Palm', we check the relative height ($y$-coordinate) of the tips against their respective base joints ($y$ decreases as you move up the frame).`,
    codeSnippet: `def is_finger_extended(landmarks, tip_idx, base_idx):
    # If the tip coordinate is above the base, it is extended
    return landmarks[tip_idx].y < landmarks[base_idx].y`
  },
  {
    id: 'cv_lag',
    title: 'Reducing Frame Latency in OpenCV Pipelines',
    date: 'Jun 28, 2026',
    tag: 'Python Optimization',
    readTime: '6 min read',
    summary: 'How multi-threaded frame acquisition bypasses standard blocking reads in OpenCV and increases model processing speed from 24FPS to 120FPS.',
    content: `The primary bottleneck in standard webcam pipelines is that \`cv2.VideoCapture().read()\` is blocking. The main thread halts while waiting for physical hardware buffers to grab frames.

By spawning a secondary background thread whose sole responsibility is to grab frames and dump them into a queue, our model's main thread runs without blocking.

This technique is incredibly useful for real-time projects like our **Gesture-Controlled Snake Game**, keeping input latency under 5ms!`,
    codeSnippet: `from threading import Thread
import cv2

class WebCamStream:
    def __init__(self, src=0):
        self.stream = cv2.VideoCapture(src)
        self.grabbed, self.frame = self.stream.read()
        self.stopped = False
        
    def start(self):
        Thread(target=self.update, args=()).start()
        return self
        
    def update(self):
        while not self.stopped:
            self.grabbed, self.frame = self.stream.read()`
  },
  {
    id: 'parse_trig',
    title: 'Building a Trigonometric Expression Parser from Scratch',
    date: 'May 14, 2026',
    tag: 'Regex & Math',
    readTime: '5 min read',
    summary: 'A look into how raw string calculators parse brackets, mathematical operators, and scientific values in degree coordinates without using unsafe evaluators.',
    content: `Many custom calculators rely on standard \`eval()\`, which is a massive security vulnerability and returns hard-to-parse syntax errors.

To solve this for our **Advanced scientific calculator**, we utilize a mathematical parser using regular expressions and a Token Stack.

Before evaluating, we look for functions like \`sin(\` and \`cos(\`, extract the nested arguments, convert from degrees to radians, and solve them in proper mathematical BODMAS order.`,
    codeSnippet: `import re
import math

def parse_trig_expression(formula):
    # Regex matching trigonometric functions sin(x), cos(x)
    pattern = r"sin\\((\\d+)\\)"
    for match in re.finditer(pattern, formula):
        deg = float(match.group(1))
        rad = math.radians(deg)
        formula = formula.replace(match.group(0), str(math.sin(rad)))
    return formula`
  }
];
