/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Brain,
  Code2,
  Terminal,
  Cpu,
  Layers,
  Mail,
  MapPin,
  Github,
  Linkedin,
  ExternalLink,
  FileText,
  Send,
  Check,
  Gamepad2,
  Calculator as CalcIcon,
  X,
  ChevronRight,
  Sparkles,
  Camera,
  Database,
  BookOpen,
  Award,
  Star,
  History,
  Compass,
  ArrowUpRight,
  CheckCircle2,
  Play,
  Pause,
  RotateCcw,
  Zap,
  GraduationCap,
  Newspaper
} from 'lucide-react';

import { Project, Message } from './types';
import { projects } from './data';
import AIPlayground from './components/AIPlayground';
import DevLogHub from './components/DevLogHub';
import CourseExplorer from './components/CourseExplorer';

export default function App() {
  // Navigation & Interactive states
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'projects' | 'academic' | 'contact'>('dashboard');
  const [activeDemo, setActiveDemo] = useState<'snake' | 'calculator' | 'nnPlayground' | null>(null);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const [typedTitle, setTypedTitle] = useState('');
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);
  
  // Message form states
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [sentMessages, setSentMessages] = useState<Message[]>([]);
  const [showOutbox, setShowOutbox] = useState(false);

  // Resume Modal Active Tab
  const [resumeTab, setResumeTab] = useState<'education' | 'experience' | 'skills' | 'certifications'>('education');

  // Snake Game States
  const [snake, setSnake] = useState<{ x: number; y: number }[]>([{ x: 10, y: 10 }]);
  const [food, setFood] = useState<{ x: number; y: number }>({ x: 5, y: 5 });
  const [snakeDir, setSnakeDir] = useState<{ x: number; y: number }>({ x: 1, y: 0 });
  const [snakeScore, setSnakeScore] = useState(0);
  const [snakeHighScore, setSnakeHighScore] = useState(0);
  const [isSnakePlaying, setIsSnakePlaying] = useState(false);
  const [isSnakeGameOver, setIsSnakeGameOver] = useState(false);
  const [gestureMode, setGestureMode] = useState(false);
  const [gestureSimState, setGestureSimState] = useState('Tracking Hand...');
  const [simTargetPoint, setSimTargetPoint] = useState({ x: 120, y: 120 });

  // Calculator States
  const [calcDisplay, setCalcDisplay] = useState('');
  const [calcResult, setCalcResult] = useState('');
  const [calcHistory, setCalcHistory] = useState<string[]>([]);

  // Interactive Vision Pipeline States
  const [visionMode, setVisionMode] = useState<'raw' | 'canny' | 'landmarks' | 'face_mesh'>('landmarks');
  const [visionTick, setVisionTick] = useState(0);

  // Interactive Terminal Sandbox States
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "muskan@portfolio:~$ # Welcome to the Python AI sandbox.",
    "muskan@portfolio:~$ # Select a routine below to start simulation."
  ]);
  const [isTerminalRunning, setIsTerminalRunning] = useState(false);
  const [activeTermCmd, setActiveTermCmd] = useState<string | null>(null);

  // Jitter animation loop for Vision Landmarks to simulate real camera feed coordinates shifting organically
  useEffect(() => {
    const interval = setInterval(() => {
      setVisionTick((t) => t + 1);
    }, 120);
    return () => clearInterval(interval);
  }, []);

  const runTerminalCommand = (cmd: string) => {
    if (isTerminalRunning) return;
    setIsTerminalRunning(true);
    setActiveTermCmd(cmd);

    let logs: string[] = [`muskan@portfolio:~$ python ${cmd}`];
    setTerminalLogs(logs);

    let steps: string[] = [];
    if (cmd === 'train_vision.py') {
      steps = [
        "[INFO] Initializing MediaPipe Hands & Pose classifier...",
        "[DATA] Loading Kaithal hand gesture dataset (4,200 samples)...",
        "[MODEL] Binding CNN architecture layer layout...",
        "[TRAIN] Epoch 1/5 - Loss: 0.421 - Accuracy: 85.3%",
        "[TRAIN] Epoch 2/5 - Loss: 0.210 - Accuracy: 94.1%",
        "[TRAIN] Epoch 3/5 - Loss: 0.115 - Accuracy: 97.5%",
        "[TRAIN] Epoch 4/5 - Loss: 0.082 - Accuracy: 98.8%",
        "[TRAIN] Epoch 5/5 - Loss: 0.054 - Accuracy: 99.4%",
        "[EVAL] Confusion Matrix plotted. Precision: 0.992, Recall: 0.995",
        "[SUCCESS] Model weights saved as './weights/gesture_model_v2.pth'!",
        "muskan@portfolio:~$"
      ];
    } else if (cmd === 'test_pipeline.py') {
      steps = [
        "[INFO] Initializing OpenCV frame parser on /dev/video0...",
        "[CAMERA] Ingress resolution configured: 640x480 at 30FPS",
        "[TRACKER] Processing Frame 01 - Landmarks: 21 - Gesture: OPEN_PALM (99.1%)",
        "[TRACKER] Processing Frame 02 - Landmarks: 21 - Gesture: FIST (98.2%)",
        "[TRACKER] Processing Frame 03 - Landmarks: 21 - Gesture: PEACE_SIGN (99.5%)",
        "[TRACKER] Processing Frame 04 - Landmarks: 21 - Gesture: OK_SIGN (96.8%)",
        "[SUCCESS] Benchmark finished. Average Latency: 4.8ms (208 FPS)",
        "muskan@portfolio:~$"
      ];
    } else if (cmd === 'fetch_repo_status.py') {
      steps = [
        "[GIT] Connecting to api.github.com/users/muskan/repos...",
        "[RESOLVE] Found 12 public repositories, 4 active forks.",
        "[INFO] Pulling recent commits...",
        " - ai-snake-game: 45 commits | last push: 2 days ago",
        " - advanced-calculator: 31 commits | last push: 1 week ago",
        " - computer-vision-filters: 18 commits | last push: 3 weeks ago",
        "[SUCCESS] Cache synchronized. All local systems operational.",
        "muskan@portfolio:~$"
      ];
    }

    let index = 0;
    const addLine = () => {
      if (index < steps.length) {
        setTerminalLogs((prev) => [...prev, steps[index]]);
        index++;
        setTimeout(addLine, 300 + Math.random() * 150);
      } else {
        setIsTerminalRunning(false);
        setActiveTermCmd(null);
      }
    };
    setTimeout(addLine, 350);
  };

  // Typing animation effect for the header
  useEffect(() => {
    const titleText = "AI Application Developer | Python Developer";
    let index = 0;
    const interval = setInterval(() => {
      setTypedTitle(titleText.slice(0, index + 1));
      index++;
      if (index >= titleText.length) {
        clearInterval(interval);
      }
    }, 60);
    return () => clearInterval(interval);
  }, []);

  // Load High Score & Sent Messages from LocalStorage
  useEffect(() => {
    const savedHighScore = localStorage.getItem('muskan_snake_highscore');
    if (savedHighScore) setSnakeHighScore(parseInt(savedHighScore));

    const savedMsgs = localStorage.getItem('muskan_portfolio_messages');
    if (savedMsgs) {
      setSentMessages(JSON.parse(savedMsgs));
    }
  }, []);

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  // Form Submission
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    const newMsg: Message = {
      id: Math.random().toString(36).substring(2, 9),
      name: formData.name,
      email: formData.email,
      message: formData.message,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' ' + new Date().toLocaleDateString(),
    };

    const updatedMsgs = [newMsg, ...sentMessages];
    setSentMessages(updatedMsgs);
    localStorage.setItem('muskan_portfolio_messages', JSON.stringify(updatedMsgs));
    
    setFormSubmitted(true);
    setFormData({ name: '', email: '', message: '' });

    setTimeout(() => {
      setFormSubmitted(false);
    }, 4000);
  };

  // --- SNAKE GAME ENGINE ---
  const snakeCanvasRef = useRef<HTMLCanvasElement>(null);
  const GRID_SIZE = 20;
  const CELL_COUNT = 15;

  // Food position randomizer
  const spawnFood = () => {
    const x = Math.floor(Math.random() * CELL_COUNT);
    const y = Math.floor(Math.random() * CELL_COUNT);
    return { x, y };
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isSnakePlaying || isSnakeGameOver) return;
      switch (e.key) {
        case 'ArrowUp':
          if (snakeDir.y !== 1) setSnakeDir({ x: 0, y: -1 });
          break;
        case 'ArrowDown':
          if (snakeDir.y !== -1) setSnakeDir({ x: 0, y: 1 });
          break;
        case 'ArrowLeft':
          if (snakeDir.x !== 1) setSnakeDir({ x: -1, y: 0 });
          break;
        case 'ArrowRight':
          if (snakeDir.x !== -1) setSnakeDir({ x: 1, y: 0 });
          break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [snakeDir, isSnakePlaying, isSnakeGameOver]);

  // Main game loop
  useEffect(() => {
    if (!isSnakePlaying || isSnakeGameOver) return;

    const gameInterval = setInterval(() => {
      setSnake((prevSnake) => {
        const head = prevSnake[0];
        let nextX = head.x + snakeDir.x;
        let nextY = head.y + snakeDir.y;

        // Wall collisions
        if (nextX < 0 || nextX >= CELL_COUNT || nextY < 0 || nextY >= CELL_COUNT) {
          setIsSnakeGameOver(true);
          setIsSnakePlaying(false);
          return prevSnake;
        }

        // Self collisions
        for (const cell of prevSnake) {
          if (cell.x === nextX && cell.y === nextY) {
            setIsSnakeGameOver(true);
            setIsSnakePlaying(false);
            return prevSnake;
          }
        }

        const newSnake = [{ x: nextX, y: nextY }, ...prevSnake];

        // Eat food check
        if (nextX === food.x && nextY === food.y) {
          setSnakeScore((s) => {
            const newScore = s + 10;
            if (newScore > snakeHighScore) {
              setSnakeHighScore(newScore);
              localStorage.setItem('muskan_snake_highscore', newScore.toString());
            }
            return newScore;
          });
          setFood(spawnFood());
        } else {
          newSnake.pop();
        }

        return newSnake;
      });
    }, gestureMode ? 250 : 150); // slower in gesture mode for mock realism

    return () => clearInterval(gameInterval);
  }, [snakeDir, food, isSnakePlaying, isSnakeGameOver, gestureMode]);

  // Draw snake game board
  useEffect(() => {
    const canvas = snakeCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear board
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid mesh
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= CELL_COUNT; i++) {
      ctx.beginPath();
      ctx.moveTo(i * GRID_SIZE, 0);
      ctx.lineTo(i * GRID_SIZE, canvas.height);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i * GRID_SIZE);
      ctx.lineTo(canvas.width, i * GRID_SIZE);
      ctx.stroke();
    }

    // Draw food
    ctx.fillStyle = '#f43f5e';
    ctx.shadowColor = '#f43f5e';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.arc(
      food.x * GRID_SIZE + GRID_SIZE / 2,
      food.y * GRID_SIZE + GRID_SIZE / 2,
      GRID_SIZE / 2 - 2,
      0,
      Math.PI * 2
    );
    ctx.fill();
    ctx.shadowBlur = 0; // reset

    // Draw snake
    snake.forEach((cell, index) => {
      const isHead = index === 0;
      ctx.fillStyle = isHead ? '#3b82f6' : '#60a5fa';
      ctx.shadowColor = isHead ? '#3b82f6' : 'transparent';
      ctx.shadowBlur = isHead ? 6 : 0;
      
      // Draw rounded rects
      const x = cell.x * GRID_SIZE + 1;
      const y = cell.y * GRID_SIZE + 1;
      const w = GRID_SIZE - 2;
      const h = GRID_SIZE - 2;
      ctx.fillRect(x, y, w, h);
    });
    ctx.shadowBlur = 0;
  }, [snake, food]);

  // Simulate hand-tracking coordinate swings
  useEffect(() => {
    if (!gestureMode || !isSnakePlaying) return;

    const coordInterval = setInterval(() => {
      // Guide the simulated hand tracking point towards the food position
      const head = snake[0];
      const targetX = food.x * GRID_SIZE;
      const targetY = food.y * GRID_SIZE;

      setSimTargetPoint((prev) => {
        const dx = targetX - prev.x;
        const dy = targetY - prev.y;
        const speed = 15;
        const nextX = prev.x + Math.sign(dx) * Math.min(Math.abs(dx), speed) + (Math.random() - 0.5) * 5;
        const nextY = prev.y + Math.sign(dy) * Math.min(Math.abs(dy), speed) + (Math.random() - 0.5) * 5;
        
        // Auto-change direction based on hand tracking simulation target direction
        if (Math.abs(dx) > Math.abs(dy)) {
          if (dx > 0 && snakeDir.x !== -1) setSnakeDir({ x: 1, y: 0 });
          else if (dx < 0 && snakeDir.x !== 1) setSnakeDir({ x: -1, y: 0 });
        } else {
          if (dy > 0 && snakeDir.y !== -1) setSnakeDir({ x: 0, y: 1 });
          else if (dy < 0 && snakeDir.y !== 1) setSnakeDir({ x: 0, y: -1 });
        }

        return { x: nextX, y: nextY };
      });

      const signals = ['Gesture: UP INDEX', 'Gesture: DOWN INDEX', 'Gesture: LEFT INDEX', 'Gesture: RIGHT INDEX'];
      setGestureSimState(signals[Math.floor(Math.random() * signals.length)] + ` (${Math.round(simTargetPoint.x)}, ${Math.round(simTargetPoint.y)})`);
    }, 250);

    return () => clearInterval(coordInterval);
  }, [gestureMode, isSnakePlaying, food, snake, snakeDir]);

  const resetSnakeGame = () => {
    setSnake([{ x: 7, y: 7 }]);
    setFood({ x: 3, y: 3 });
    setSnakeDir({ x: 1, y: 0 });
    setSnakeScore(0);
    setIsSnakeGameOver(false);
    setIsSnakePlaying(true);
  };

  // --- CALCULATOR ENGINE ---
  const handleCalcPress = (val: string) => {
    if (val === 'AC') {
      setCalcDisplay('');
      setCalcResult('');
    } else if (val === 'C') {
      setCalcDisplay((prev) => prev.slice(0, -1));
    } else if (val === '=') {
      try {
        let formula = calcDisplay;
        // Replace math functions for simpler eval simulation
        formula = formula.replace(/sin\(/g, 'Math.sin(');
        formula = formula.replace(/cos\(/g, 'Math.cos(');
        formula = formula.replace(/tan\(/g, 'Math.tan(');
        formula = formula.replace(/log\(/g, 'Math.log10(');
        formula = formula.replace(/ln\(/g, 'Math.log(');
        formula = formula.replace(/√\(/g, 'Math.sqrt(');
        formula = formula.replace(/π/g, 'Math.PI');
        formula = formula.replace(/e/g, 'Math.E');
        formula = formula.replace(/\^/g, '**');

        // Solve standard trig evaluations using degree conversions
        if (formula.includes('Math.sin') || formula.includes('Math.cos') || formula.includes('Math.tan')) {
          // Parse single trig argument inside to convert degrees to radians
          formula = formula.replace(/Math\.(sin|cos|tan)\(([^)]+)\)/g, (_, func, arg) => {
            try {
              // evaluate nested arg
              const evaluatedArg = Function(`"use strict"; return (${arg})`)();
              const rad = (evaluatedArg * Math.PI) / 180;
              return `Math.${func}(${rad})`;
            } catch {
              return `Math.${func}(${arg})`;
            }
          });
        }

        // Evaluate using safe Function evaluator
        const res = Function(`"use strict"; return (${formula})`)();
        
        if (res !== undefined && !isNaN(res)) {
          const finalResult = Number(res.toFixed(5)).toString();
          setCalcResult(finalResult);
          
          // Save history
          const historyEntry = `${calcDisplay} = ${finalResult}`;
          setCalcHistory((prev) => [historyEntry, ...prev.slice(0, 9)]);
        } else {
          setCalcResult('Error');
        }
      } catch (err) {
        setCalcResult('Syntax Error');
      }
    } else {
      // Append value
      setCalcDisplay((prev) => prev + val);
    }
  };

  // Skill database tooltips description mapping
  const skillDescriptions: { [key: string]: string } = {
    Python: "Muskan's primary language. Proficient in OOP, algorithm optimization, automation scripts, and custom GUI engines.",
    'Artificial Intelligence': "Experienced with deep learning architectures, CNNs, image preprocessing, and computer vision classification tasks.",
    OpenCV: "Specialized in real-time camera manipulation, video processing pipelines, filters, and smart gesture tracking.",
    MediaPipe: "Expertise in hand landmarker tracking, pose estimation pipelines, and face mesh models.",
    NumPy: "Vectorized computing, complex matrix array mathematics, and geometric calculations for image frames.",
    Pandas: "Structured data pipelines, CSV querying, analysis metrics, and model feature data preparation.",
    'Machine Learning': "Supervised algorithms, regression, classifier decision trees, Scikit-Learn pipelines, and model fine-tuning.",
    SQL: "Database queries, table designs, schema relations, filtering, and storage normalization layouts.",
    JavaScript: "Front-end interactive components, dynamic web layouts, interactive visualizations, and React states.",
    'Git & GitHub': "Version control workflows, trunk branches, code reviews, staging, and remote repository distribution."
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 font-sans overflow-x-hidden relative flex flex-col p-4 md:p-6 gap-6 selection:bg-blue-500/30">
      {/* Background Decorative Ambient Glows */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/15 blur-[120px] rounded-full pointer-events-none z-0" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/15 blur-[120px] rounded-full pointer-events-none z-0" />

      {/* NAV BAR */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-3 bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center font-bold text-lg text-white shadow-md shadow-blue-500/25">
            M
          </div>
          <span className="text-lg font-bold tracking-tight">
            Muskan<span className="text-blue-500">.</span>
          </span>
        </div>

        <div className="hidden md:flex gap-8 text-sm font-medium text-slate-400">
          <button
            onClick={() => setCurrentPage('dashboard')}
            className={`transition-colors cursor-pointer ${
              currentPage === 'dashboard' ? 'text-white border-b-2 border-blue-500 pb-0.5' : 'hover:text-white'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setCurrentPage('projects')}
            className={`transition-colors cursor-pointer ${
              currentPage === 'projects' ? 'text-white border-b-2 border-blue-500 pb-0.5' : 'hover:text-white'
            }`}
          >
            Projects
          </button>
          <button
            onClick={() => setCurrentPage('academic')}
            className={`transition-colors cursor-pointer ${
              currentPage === 'academic' ? 'text-white border-b-2 border-blue-500 pb-0.5' : 'hover:text-white'
            }`}
          >
            Academic
          </button>
          <button
            onClick={() => setCurrentPage('contact')}
            className={`transition-colors cursor-pointer ${
              currentPage === 'contact' ? 'text-white border-b-2 border-blue-500 pb-0.5' : 'hover:text-white'
            }`}
          >
            Contact
          </button>
        </div>

        <div className="flex items-center gap-4 relative z-10">
          <div className="flex gap-3">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub Profile"
              className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-all"
            >
              <Github size={16} />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn Profile"
              className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-all"
            >
              <Linkedin size={16} />
            </a>
          </div>
          <button 
            id="nav-resume-btn"
            onClick={() => setIsResumeOpen(true)} 
            className="px-4 py-1.5 bg-white text-black text-xs font-bold rounded-full hover:bg-slate-200 hover:scale-105 active:scale-95 transition-all shadow-md shadow-white/10 cursor-pointer"
          >
            Resume
          </button>
        </div>
      </nav>

      {/* MOBILE PILLED TAB BAR */}
      <div className="flex md:hidden justify-between p-1 bg-white/5 border border-white/10 rounded-xl font-mono text-[10px] gap-1 relative z-10">
        {[
          { id: 'dashboard', label: 'Dashboard' },
          { id: 'projects', label: 'Projects' },
          { id: 'academic', label: 'Academic' },
          { id: 'contact', label: 'Contact' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setCurrentPage(tab.id as any)}
            className={`flex-1 py-2 rounded-lg font-bold transition-all text-center cursor-pointer ${
              currentPage === tab.id
                ? 'bg-blue-600 text-white shadow font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* MAIN PORTFOLIO BENTO GRID */}
      <main className="flex-grow grid grid-cols-1 md:grid-cols-12 gap-4 relative z-10">
        
        {/* HERO CARD (Col-Span 7) */}
        <div id="hero-card" className={`col-span-1 md:col-span-7 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 md:p-8 flex flex-col justify-center relative overflow-hidden group min-h-[350px] ${currentPage === 'dashboard' ? '' : 'hidden'}`}>
          <div className="absolute top-0 right-0 p-8 text-7xl md:text-8xl opacity-5 font-bold font-mono pointer-events-none text-blue-500">
            AI
          </div>
          <h2 className="text-blue-400 font-mono text-sm mb-2 select-text tracking-wider">// Hello World</h2>
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4 tracking-tight">
            I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 animate-pulse">Muskan</span>
          </h1>
          
          <div className="h-8 mb-4">
            <p className="text-lg md:text-xl text-slate-300 font-light max-w-md flex items-center">
              {typedTitle}
              <span className="animate-ping ml-1 text-blue-500 font-semibold">|</span>
            </p>
          </div>

          <p className="text-slate-400 max-w-md text-sm md:text-base leading-relaxed">
            Aspiring developer focused on building practical AI solutions, high-speed Python automation engines, and real-time Computer Vision applications from Kaithal, India.
          </p>
          
          <div className="mt-8 flex flex-wrap gap-4">
            <a 
              href="#projects"
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 rounded-xl font-bold text-sm tracking-wide shadow-lg shadow-blue-600/25 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>View Projects</span>
              <ChevronRight size={16} />
            </a>
            <button 
              onClick={() => setIsResumeOpen(true)}
              className="px-6 py-3 bg-white/10 border border-white/10 hover:bg-white/15 rounded-xl font-bold text-sm transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <FileText size={16} />
              <span>Full CV</span>
            </button>
          </div>
        </div>

        {/* CORE EXPERTISE (Col-Span 5) */}
        <div id="expertise-card" className={`col-span-1 md:col-span-5 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden group ${currentPage === 'dashboard' ? '' : 'hidden'}`}>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-500 rounded-full animate-ping"></span> 
              <span>Core Expertise</span>
            </h3>
            
            <div className="grid grid-cols-2 gap-2">
              {Object.keys(skillDescriptions).map((skill) => (
                <div
                  key={skill}
                  onMouseEnter={() => setHoveredSkill(skill)}
                  onMouseLeave={() => setHoveredSkill(null)}
                  className={`px-3 py-2 bg-white/5 border border-white/5 rounded-xl text-xs font-medium text-slate-300 hover:border-blue-500/40 hover:bg-blue-500/5 hover:text-blue-300 transition-all duration-300 flex items-center justify-between cursor-pointer group/item`}
                >
                  <span>{skill}</span>
                  <Sparkles size={12} className="opacity-0 group-hover/item:opacity-100 text-purple-400 transition-all ml-1" />
                </div>
              ))}
            </div>
          </div>

          {/* Skill Details Tooltip Panel */}
          <div className="mt-4 pt-3 border-t border-white/5 min-h-[50px] flex items-center">
            <AnimatePresence mode="wait">
              {hoveredSkill ? (
                <motion.p
                  key={hoveredSkill}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="text-xs text-blue-300/90 leading-relaxed font-mono"
                >
                  <span className="text-slate-400">&gt; </span>
                  {skillDescriptions[hoveredSkill]}
                </motion.p>
              ) : (
                <p className="text-xs text-slate-500 italic font-mono">
                  Hover over any expertise skill pill to view implementation records.
                </p>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* INTERACTIVE COMPUTER VISION PIPELINE STUDIO (Col-Span 7) */}
        <div id="vision-studio-card" className={`col-span-1 md:col-span-7 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden group hover:border-blue-500/30 transition-all duration-300 ${currentPage === 'dashboard' ? '' : 'hidden'}`}>
          <div className="absolute top-[-10%] right-[-10%] w-[30%] h-[30%] bg-blue-500/5 blur-[50px] rounded-full pointer-events-none" />
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 flex items-center gap-2">
                <Camera size={14} className="text-blue-400 animate-pulse" />
                <span>Interactive Vision Studio</span>
              </h3>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5">MediaPipe & OpenCV pipeline simulation</p>
            </div>

            {/* Selector Pills */}
            <div className="flex flex-wrap gap-1 bg-black/40 p-1 rounded-xl border border-white/5 font-mono text-[9px] relative z-10">
              {[
                { id: 'raw', label: 'Raw' },
                { id: 'canny', label: 'Canny' },
                { id: 'landmarks', label: 'Hands' },
                { id: 'face_mesh', label: 'Face' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setVisionMode(m.id as any)}
                  className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    visionMode === m.id
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Screen Viewport */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-stretch relative z-10">
            {/* Simulated Frame Viewport */}
            <div className="sm:col-span-7 bg-slate-950/80 rounded-2xl border border-white/10 aspect-[4/3] flex flex-col items-center justify-center relative overflow-hidden">
              <div className="absolute top-2 left-2 text-[8px] font-mono text-emerald-400 bg-black/50 px-1.5 py-0.5 rounded flex items-center gap-1 border border-emerald-500/20">
                <span className="w-1 h-1 bg-emerald-500 rounded-full animate-ping"></span>
                <span>SIM_CAM_0: {visionMode.toUpperCase()}</span>
              </div>
              <div className="absolute top-2 right-2 text-[8px] font-mono text-slate-400">
                FPS: {30 + (visionTick % 2)} | Latency: {(3.8 + (visionTick % 3) * 0.4).toFixed(1)}ms
              </div>

              {/* Interactive Vector Art Canvas based on active filter */}
              <div className="w-full h-full flex items-center justify-center p-6 select-none relative">
                {/* SVG Vector Frame */}
                <svg
                  className={`w-full h-full max-h-[160px] transition-all duration-300 ${
                    visionMode === 'canny' ? 'filter invert brightness-125' : ''
                  } ${visionMode === 'raw' ? 'filter grayscale-0' : 'filter grayscale'}`}
                  viewBox="0 0 120 100"
                >
                  {visionMode === 'face_mesh' ? (
                    // Face Mesh Simulation
                    <g className="transition-all duration-300">
                      {/* Face contour outline */}
                      <path
                        d="M30,30 Q60,15 90,30 Q95,65 60,90 Q25,65 30,30 Z"
                        fill="none"
                        stroke={visionMode === 'canny' ? '#10b981' : '#3b82f6'}
                        strokeWidth="0.5"
                        strokeDasharray={visionMode === 'canny' ? 'none' : '1 1'}
                      />
                      {/* Eyes */}
                      <ellipse cx="48" cy="40" rx="6" ry="3" fill="none" stroke={visionMode === 'canny' ? '#10b981' : '#3b82f6'} strokeWidth="0.5" />
                      <ellipse cx="72" cy="40" rx="6" ry="3" fill="none" stroke={visionMode === 'canny' ? '#10b981' : '#3b82f6'} strokeWidth="0.5" />
                      {/* Pupils */}
                      <circle cx={48 + Math.sin(visionTick / 5) * 0.8} cy="40" r="1.5" fill={visionMode === 'canny' ? '#10b981' : '#60a5fa'} />
                      <circle cx={72 + Math.sin(visionTick / 5) * 0.8} cy="40" r="1.5" fill={visionMode === 'canny' ? '#10b981' : '#60a5fa'} />
                      {/* Nose */}
                      <path d="M60,40 L58,55 L62,55 Z" fill="none" stroke={visionMode === 'canny' ? '#10b981' : '#3b82f6'} strokeWidth="0.5" />
                      {/* Mouth */}
                      <path d="M48,68 Q60,78 72,68" fill="none" stroke={visionMode === 'canny' ? '#10b981' : '#3b82f6'} strokeWidth="0.5" />

                      {/* Mesh Landmark Dots & Connecting Threads */}
                      {visionMode !== 'raw' && (
                        <g className="opacity-85 text-[1px] font-mono">
                          {/* Mesh connection wires */}
                          <line x1="48" y1="40" x2="60" y2="40" stroke="#10b981" strokeWidth="0.2" />
                          <line x1="72" y1="40" x2="60" y2="40" stroke="#10b981" strokeWidth="0.2" />
                          <line x1="48" y1="40" x2="58" y2="55" stroke="#10b981" strokeWidth="0.2" />
                          <line x1="72" y1="40" x2="62" y2="55" stroke="#10b981" strokeWidth="0.2" />
                          <line x1="58" y1="55" x2="60" y2="68" stroke="#10b981" strokeWidth="0.2" />
                          <line x1="62" y1="55" x2="60" y2="68" stroke="#10b981" strokeWidth="0.2" />
                          {/* Face border coordinates */}
                          <circle cx="30" cy="30" r="1" fill="#34d399" />
                          <circle cx="90" cy="30" r="1" fill="#34d399" />
                          <circle cx="60" cy="15" r="1" fill="#34d399" />
                          <circle cx="60" cy="90" r="1" fill="#34d399" />
                          {/* Eyes coordinates */}
                          <circle cx="42" cy="40" r="0.7" fill="#60a5fa" />
                          <circle cx="54" cy="40" r="0.7" fill="#60a5fa" />
                          <circle cx="66" cy="40" r="0.7" fill="#60a5fa" />
                          <circle cx="78" cy="40" r="0.7" fill="#60a5fa" />
                        </g>
                      )}
                    </g>
                  ) : (
                    // Hands / Skeletal Landmarks Simulation
                    <g className="transition-all duration-300">
                      {/* Palm structure representation */}
                      <path
                        d="M40,80 Q45,55 50,45 T60,35 T70,38 T78,44 T80,80 Z"
                        fill="none"
                        stroke={visionMode === 'canny' ? '#10b981' : '#3b82f6'}
                        strokeWidth="0.5"
                      />
                      
                      {/* Landmark Lines */}
                      {visionMode !== 'raw' && (
                        <g stroke={visionMode === 'canny' ? '#10b981' : '#3b82f6'} strokeWidth="0.4" className="opacity-90">
                          {/* Thumb (Base coordinates index 1 -> 4) */}
                          <line x1="45" y1="72" x2="35" y2="64" />
                          <line x1="35" y1="64" x2="28" y2="58" />
                          <line x1="28" y1="58" x2="23" y2="53" />

                          {/* Index Finger (index 5 -> 8) */}
                          <line x1="50" y1="52" x2="48" y2="40" />
                          <line x1="48" y1="40" x2="46" y2="30" />
                          <line x1="46" y1="30" x2="44" y2="21" />

                          {/* Middle Finger (index 9 -> 12) */}
                          <line x1="58" y1="48" x2="58" y2="34" />
                          <line x1="58" y1="34" x2="58" y2="22" />
                          <line x1="58" y1="22" x2="58" y2="12" />

                          {/* Ring Finger (index 13 -> 16) */}
                          <line x1="66" y1="50" x2="68" y2="38" />
                          <line x1="68" y1="38" x2="70" y2="28" />
                          <line x1="70" y1="28" x2="72" y2="20" />

                          {/* Pinky Finger (index 17 -> 20) */}
                          <line x1="74" y1="56" x2="78" y2="46" />
                          <line x1="78" y1="46" x2="82" y2="38" />
                          <line x1="82" y1="38" x2="86" y2="30" />
                        </g>
                      )}

                      {/* Landmarks glowing vertices */}
                      {visionMode !== 'raw' && (
                        <g fill="#10b981" className="filter drop-shadow-[0_0_2px_#10b981]">
                          <circle cx="45" cy="72" r="1" />
                          <circle cx="35" cy="64" r="1" />
                          <circle cx="28" cy="58" r="1" />
                          <circle cx="23" cy="53" r="1" fill="#38bdf8" /> {/* Thumb Tip */}
                          
                          <circle cx="50" cy="52" r="1" />
                          <circle cx="48" cy="40" r="1" />
                          <circle cx="46" cy="30" r="1" />
                          <circle cx="44" cy="21" r="1.2" fill="#38bdf8" /> {/* Index Tip */}

                          <circle cx="58" cy="48" r="1" />
                          <circle cx="58" cy="34" r="1" />
                          <circle cx="58" cy="22" r="1" />
                          <circle cx="58" cy="12" r="1.2" fill="#38bdf8" /> {/* Middle Tip */}

                          <circle cx="66" cy="50" r="1" />
                          <circle cx="68" cy="38" r="1" />
                          <circle cx="70" cy="28" r="1" />
                          <circle cx="72" cy="20" r="1.2" fill="#38bdf8" /> {/* Ring Tip */}

                          <circle cx="74" cy="56" r="1" />
                          <circle cx="78" cy="46" r="1" />
                          <circle cx="82" cy="38" r="1" />
                          <circle cx="86" cy="30" r="1.2" fill="#38bdf8" /> {/* Pinky Tip */}
                        </g>
                      )}
                    </g>
                  )}
                </svg>

                {/* Subtitle Telemetry Display inside video frame */}
                <div className="absolute bottom-1.5 left-0 right-0 text-center text-[8px] font-mono bg-black/70 py-1 text-slate-300">
                  {visionMode === 'raw' && "RAW FRAME CAPTURED"}
                  {visionMode === 'canny' && "OPENCV: cv2.Canny(img, threshold1=100, threshold2=200)"}
                  {visionMode === 'landmarks' && "GESTURE DETECTED: PEACE_SIGN (98.4%)"}
                  {visionMode === 'face_mesh' && "LANDMARKS DETECTED: 468 INDEPENDENT NODES"}
                </div>
              </div>
            </div>

            {/* Simulated Vision Telemetry Side bar & Code snippets */}
            <div className="sm:col-span-5 flex flex-col justify-between font-mono text-[10px] space-y-2 bg-slate-900/60 p-3 rounded-2xl border border-white/5">
              <div className="space-y-1.5">
                <span className="text-blue-400 font-bold tracking-wide uppercase text-[8px]">&gt;_ Pipeline Variables</span>
                <div className="space-y-1 text-slate-300 text-[9px]">
                  <p className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Device:</span>
                    <span>HD Webcam</span>
                  </p>
                  <p className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Dim:</span>
                    <span>640 × 480</span>
                  </p>
                  <p className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-500">Channels:</span>
                    <span>{visionMode === 'canny' ? '1 (Grayscale)' : '3 (RGB)'}</span>
                  </p>
                  <p className="flex justify-between">
                    <span className="text-slate-500">Points:</span>
                    <span>{visionMode === 'landmarks' ? '21 points' : visionMode === 'face_mesh' ? '468 mesh' : 'N/A'}</span>
                  </p>
                </div>
              </div>

              <div className="space-y-1 bg-black/40 p-2 rounded-lg text-slate-400 text-[8px] leading-normal select-text">
                <p className="text-blue-300">import cv2</p>
                <p className="text-purple-300">import mediapipe as mp</p>
                {visionMode === 'canny' && (
                  <>
                    <p className="text-slate-500"># Apply edge filters</p>
                    <p>edges = cv2.Canny(frame, 100, 200)</p>
                  </>
                )}
                {visionMode === 'landmarks' && (
                  <>
                    <p className="text-slate-500"># Detect pose landmarks</p>
                    <p>results = hands.process(img)</p>
                    <p className="text-emerald-400">cv2.circle(img, (x,y), 5)</p>
                  </>
                )}
                {visionMode === 'face_mesh' && (
                  <>
                    <p className="text-slate-500"># Detect dense face coordinates</p>
                    <p>results = face_mesh.process(img)</p>
                  </>
                )}
                {visionMode === 'raw' && (
                  <>
                    <p className="text-slate-500"># Capture live frame raw</p>
                    <p>ret, frame = cap.read()</p>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* INTERACTIVE TERMINAL & FOCUS PANEL (Col-Span 5) */}
        <div id="terminal-sandbox-card" className={`col-span-1 md:col-span-5 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-5 flex flex-col justify-between relative overflow-hidden group hover:border-purple-500/30 transition-all duration-300 ${currentPage === 'dashboard' ? '' : 'hidden'}`}>
          <div className="absolute top-[-10%] left-[-10%] w-[30%] h-[30%] bg-purple-500/5 blur-[50px] rounded-full pointer-events-none" />
          
          <div className="flex justify-between items-center mb-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 flex items-center gap-2">
                <Terminal size={14} className="text-purple-400" />
                <span>Python Sandbox</span>
              </h3>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5">Mock script execution unit</p>
            </div>
            
            {/* Blinking State indicator */}
            <div className="flex items-center gap-1.5 text-[9px] font-mono">
              <span className={`w-1.5 h-1.5 rounded-full ${isTerminalRunning ? 'bg-amber-400 animate-ping' : 'bg-slate-500'}`} />
              <span className={isTerminalRunning ? 'text-amber-400' : 'text-slate-500'}>
                {isTerminalRunning ? 'COMPUTING' : 'READY'}
              </span>
            </div>
          </div>

          {/* Interactive Shell Terminal Display */}
          <div className="bg-black/85 border border-white/10 rounded-2xl p-3 font-mono text-[9px] leading-relaxed text-slate-300 h-36 flex flex-col justify-between mb-3 overflow-hidden select-text">
            <div className="overflow-y-auto flex-grow space-y-1 scrollbar-thin scrollbar-thumb-white/10 pr-1">
              {terminalLogs.map((log, idx) => (
                <p
                  key={idx}
                  className={
                    log.startsWith('muskan@portfolio:~$')
                      ? 'text-purple-400 font-bold'
                      : log.startsWith('[SUCCESS]')
                      ? 'text-emerald-400 font-bold'
                      : log.startsWith('[EVAL]') || log.startsWith('[TRAIN]')
                      ? 'text-blue-300'
                      : log.startsWith('[INFO]') || log.startsWith('[DATA]')
                      ? 'text-slate-400'
                      : 'text-slate-300 pl-1'
                  }
                >
                  {log}
                </p>
              ))}
              {isTerminalRunning && (
                <div className="inline-block w-1.5 h-3 bg-blue-400 animate-pulse ml-0.5" />
              )}
            </div>
            <div className="text-[8px] text-slate-500 border-t border-white/5 pt-1 mt-1 flex justify-between">
              <span>SANDBOX HOST: KAITHAL_ENV</span>
              <span>BUFFER: NORMAL</span>
            </div>
          </div>

          {/* Preset Commands / Script Buttons */}
          <div className="space-y-2 relative z-10">
            <span className="text-[8px] uppercase tracking-wider text-slate-500 font-mono block font-bold">Select Script to Execute:</span>
            
            <div className="grid grid-cols-3 gap-1.5">
              <button
                disabled={isTerminalRunning}
                onClick={() => runTerminalCommand('train_vision.py')}
                className={`py-1.5 px-1 rounded-xl border font-mono text-[9px] font-bold transition-all active:scale-95 text-center flex flex-col items-center gap-0.5 cursor-pointer ${
                  activeTermCmd === 'train_vision.py'
                    ? 'bg-amber-500/25 border-amber-500/55 text-amber-300'
                    : 'bg-white/5 border-white/5 hover:border-purple-500/20 hover:bg-purple-500/5 text-slate-300 hover:text-white'
                }`}
              >
                <Cpu size={12} className={activeTermCmd === 'train_vision.py' ? 'animate-spin' : ''} />
                <span>Train CNN</span>
              </button>

              <button
                disabled={isTerminalRunning}
                onClick={() => runTerminalCommand('test_pipeline.py')}
                className={`py-1.5 px-1 rounded-xl border font-mono text-[9px] font-bold transition-all active:scale-95 text-center flex flex-col items-center gap-0.5 cursor-pointer ${
                  activeTermCmd === 'test_pipeline.py'
                    ? 'bg-blue-500/25 border-blue-500/55 text-blue-300'
                    : 'bg-white/5 border-white/5 hover:border-blue-500/20 hover:bg-blue-500/5 text-slate-300 hover:text-white'
                }`}
              >
                <Layers size={12} className={activeTermCmd === 'test_pipeline.py' ? 'animate-bounce' : ''} />
                <span>Test CV</span>
              </button>

              <button
                disabled={isTerminalRunning}
                onClick={() => runTerminalCommand('fetch_repo_status.py')}
                className={`py-1.5 px-1 rounded-xl border font-mono text-[9px] font-bold transition-all active:scale-95 text-center flex flex-col items-center gap-0.5 cursor-pointer ${
                  activeTermCmd === 'fetch_repo_status.py'
                    ? 'bg-emerald-500/25 border-emerald-500/55 text-emerald-300'
                    : 'bg-white/5 border-white/5 hover:border-emerald-500/20 hover:bg-emerald-500/5 text-slate-300 hover:text-white'
                }`}
              >
                <Github size={12} />
                <span>Sync Git</span>
              </button>
            </div>
          </div>
        </div>

        {/* FEATURED PROJECTS PAGE (Col-Span 12, shown on projects page) */}
        <div 
          id="projects" 
          className={`col-span-1 md:col-span-8 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex flex-col gap-4 scroll-mt-6 ${
            currentPage === 'projects' ? '' : 'hidden'
          }`}
        >
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 flex items-center gap-2">
                <Code2 size={16} className="text-blue-500" />
                <span>Engineering Projects Showcase</span>
              </h3>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5">Muskan's Core Implementation Works</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {projects.map((proj) => (
              <div 
                key={proj.id}
                className="bg-slate-900/55 border border-white/5 rounded-2xl p-5 hover:border-blue-500/40 hover:bg-slate-900/80 transition-all group/proj relative overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-extrabold text-sm text-slate-100 group-hover/proj:text-white">{proj.title}</h4>
                    <span className={`text-[10px] ${proj.tag === 'OpenCV' ? 'bg-blue-500/20 text-blue-300' : 'bg-purple-500/20 text-purple-300'} px-2.5 py-0.5 rounded-full font-semibold`}>
                      {proj.tag}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mb-4 leading-relaxed line-clamp-2">
                    {proj.desc}
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono mb-6 leading-normal line-clamp-3">
                    {proj.longDesc || "Fully functional interactive developer pipeline with high efficiency computation layers and multi-threaded script backends."}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setActiveProject(proj)}
                    className="text-[10px] font-bold text-slate-300 border border-white/10 hover:bg-white/5 px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <BookOpen size={10} />
                    <span>Specs Sheet</span>
                  </button>
                  <button 
                    onClick={() => setActiveDemo(proj.demoId)}
                    className="text-[10px] font-bold text-white bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-md shadow-blue-600/10 active:scale-95 transition-all cursor-pointer"
                  >
                    <Play size={10} className="fill-white" />
                    <span>Run Demo</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SIDE BAR PLAYGROUND LAUNCHER (Shown only on projects page) */}
        <div 
          className={`col-span-1 md:col-span-4 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden ${
            currentPage === 'projects' ? '' : 'hidden'
          }`}
        >
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 flex items-center gap-2">
                <Sparkles size={14} className="text-purple-400 animate-pulse" />
                <span>Interactive Playgrounds</span>
              </h3>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5">Simulated in-browser environment models</p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => setActiveDemo('nnPlayground')}
                className="w-full text-left p-4 bg-gradient-to-br from-emerald-500/10 to-teal-500/5 hover:from-emerald-500/20 border border-emerald-500/20 hover:border-emerald-500/40 rounded-2xl transition-all active:scale-[0.98] group cursor-pointer"
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                    <Cpu size={12} className="animate-spin" style={{ animationDuration: '4s' }} />
                    <span>Neural Network Model</span>
                  </span>
                  <ChevronRight size={12} className="text-slate-500 group-hover:text-emerald-400 transition-colors" />
                </div>
                <p className="text-[10px] text-slate-400 leading-normal">Interactive multi-layer perceptron. Train models, adjust nodes, see gradients converge in real time.</p>
              </button>

              <button
                onClick={() => setActiveDemo('snake')}
                className="w-full text-left p-4 bg-gradient-to-br from-blue-500/10 to-indigo-500/5 hover:from-blue-500/20 border border-blue-500/20 hover:border-blue-500/40 rounded-2xl transition-all active:scale-[0.98] group cursor-pointer"
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                    <Gamepad2 size={12} />
                    <span>Computer Vision Snake</span>
                  </span>
                  <ChevronRight size={12} className="text-slate-500 group-hover:text-blue-400 transition-colors" />
                </div>
                <p className="text-[10px] text-slate-400 leading-normal">Control utilizing responsive webcam coordinate loops or keyboards. Blends trigonometry with vectors.</p>
              </button>

              <button
                onClick={() => setActiveDemo('calculator')}
                className="w-full text-left p-4 bg-gradient-to-br from-purple-500/10 to-pink-500/5 hover:from-purple-500/20 border border-purple-500/20 hover:border-purple-500/40 rounded-2xl transition-all active:scale-[0.98] group cursor-pointer"
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                    <CalcIcon size={12} />
                    <span>Formula Calculator</span>
                  </span>
                  <ChevronRight size={12} className="text-slate-500 group-hover:text-purple-400 transition-colors" />
                </div>
                <p className="text-[10px] text-slate-400 leading-normal">Scientific algebraic parsing engine. Evaluate formula chains and log mathematical session history.</p>
              </button>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-white/5 text-[9px] text-slate-500 font-mono flex items-center justify-between">
            <span>ACTIVE DEMOS: 3</span>
            <span>SYSTEM: SECURE_SANDBOX</span>
          </div>
        </div>

        {/* EDUCATION & CONTACT DIRECTORY (Col-Span 12) */}
        <div id="contact" className={`col-span-1 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 md:p-8 flex flex-col md:flex-row justify-between gap-6 md:gap-8 scroll-mt-6 transition-all duration-300 ${currentPage === 'contact' ? 'md:col-span-12' : 'hidden'}`}>
          <div className="flex-1 flex flex-col justify-between gap-4">
            <div className="space-y-4">
              <div>
                <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                  <GraduationCap size={14} className="text-purple-400" />
                  <span>Education</span>
                </h3>
                <p className="text-xs font-bold text-slate-200">B.Sc. Computer Science</p>
                <p className="text-[10px] text-slate-400 font-mono">AI App Development Spec. • Graduated 2024</p>
              </div>

              <div>
                <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                  <Mail size={12} className="text-blue-400" />
                  <span>Contact Info</span>
                </h3>
                <div className="space-y-2 text-[11px] text-slate-300 font-mono">
                  <p className="flex items-center gap-2">
                    <Mail size={12} className="text-slate-500" />
                    <span>muskanchauhan88330044@gmail.com</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <MapPin size={12} className="text-slate-500" />
                    <span>Kaithal, Haryana, India</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Collapsible Inbox / Sent message history trigger */}
            {sentMessages.length > 0 && (
              <div className="pt-2">
                <button
                  onClick={() => setShowOutbox(!showOutbox)}
                  className="text-[10px] text-blue-400 hover:text-blue-300 hover:underline flex items-center gap-1 cursor-pointer font-mono"
                >
                  <History size={10} />
                  <span>{showOutbox ? 'Hide Sent Messages' : `View Sent Outbox (${sentMessages.length})`}</span>
                </button>
              </div>
            )}
          </div>

          <div className="flex-1 md:border-l md:border-white/5 md:pl-6">
            <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-1.5">
              <Send size={12} className="text-emerald-400" />
              <span>Quick Message Portal</span>
            </h3>

            <form onSubmit={handleFormSubmit} className="space-y-2.5">
              <input
                type="text"
                required
                placeholder="Your Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:bg-white/10 transition-all font-mono"
              />
              <input
                type="email"
                required
                placeholder="Email Address"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:bg-white/10 transition-all font-mono"
              />
              <textarea
                required
                rows={2}
                placeholder="Your Message"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:bg-white/10 transition-all font-mono resize-none"
              />
              
              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 rounded-xl text-xs font-bold transition-all transform active:scale-95 flex items-center justify-center gap-1.5 shadow-lg shadow-purple-600/15 cursor-pointer"
              >
                {formSubmitted ? (
                  <>
                    <Check size={14} className="text-green-300" />
                    <span className="text-green-300">Message Dispatched!</span>
                  </>
                ) : (
                  <>
                    <Send size={12} />
                    <span>Transmit Message</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>

        {/* ACADEMIC COURSEWORK EXPLORER (Col-Span 7) */}
        <div id="coursework-card" className={`col-span-1 md:col-span-7 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 hover:border-blue-500/30 transition-all duration-300 ${currentPage === 'academic' ? '' : 'hidden'}`}>
          <CourseExplorer />
        </div>

        {/* ENGINEERING DEVLOG (Col-Span 5) */}
        <div id="devlog-card" className={`col-span-1 md:col-span-5 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 hover:border-purple-500/30 transition-all duration-300 ${currentPage === 'academic' ? '' : 'hidden'}`}>
          <DevLogHub />
        </div>

      </main>

      {/* FOOTER */}
      <footer className="relative z-10 mt-auto flex flex-col sm:flex-row justify-between items-center text-[10px] text-slate-500 px-2 gap-2 pt-4 border-t border-white/5">
        <p>&copy; 2024 Muskan. All Rights Reserved.</p>
        <p className="flex items-center gap-1">
          <span>Built with</span>
          <span className="text-red-500 animate-pulse">♥</span>
          <span>for the AI Future</span>
        </p>
      </footer>

      {/* INTERACTIVE OUTBOX POPUP PANEL */}
      <AnimatePresence>
        {showOutbox && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-40 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-slate-900 border border-white/15 w-full max-w-lg rounded-3xl p-6 relative shadow-2xl overflow-hidden max-h-[80vh] flex flex-col"
            >
              <div className="flex justify-between items-center pb-4 border-b border-white/10 mb-4">
                <div className="flex items-center gap-2">
                  <History size={16} className="text-blue-400" />
                  <h3 className="font-bold text-base text-white">Sent Messages Outbox</h3>
                </div>
                <button 
                  onClick={() => setShowOutbox(false)}
                  className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="flex-grow overflow-y-auto space-y-3 pr-1">
                {sentMessages.map((msg) => (
                  <div key={msg.id} className="bg-white/5 border border-white/5 p-3 rounded-2xl relative">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-semibold text-xs text-blue-300">{msg.name}</span>
                      <span className="text-[9px] text-slate-500 font-mono">{msg.timestamp}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono mb-1">{msg.email}</p>
                    <p className="text-xs text-slate-200 leading-relaxed bg-black/20 p-2.5 rounded-xl font-mono whitespace-pre-wrap">
                      {msg.message}
                    </p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SPECIFICATIONS DETAILS MODAL */}
      <AnimatePresence>
        {activeProject && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-950 border border-white/15 w-full max-w-lg rounded-3xl p-6 relative shadow-2xl overflow-hidden"
            >
              <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[60px] rounded-full pointer-events-none" />
              
              <div className="flex justify-between items-start mb-4">
                <div>
                  <span className="text-[9px] font-mono tracking-widest text-blue-400 uppercase font-bold">&gt;_ PROJECT ARCHITECTURE</span>
                  <h3 className="text-2xl font-extrabold text-white mt-1">{activeProject.title}</h3>
                </div>
                <button
                  onClick={() => setActiveProject(null)}
                  className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-4 relative z-10">
                <p className="text-sm text-slate-300 leading-relaxed font-sans">
                  {activeProject.longDesc}
                </p>

                <div>
                  <h4 className="text-xs font-bold uppercase text-slate-400 mb-2 font-mono">Engine Tech Stack:</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {activeProject.tech.map((t) => (
                      <span key={t} className="px-2.5 py-1 bg-white/5 border border-white/10 rounded-lg text-xs font-mono text-slate-300">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 flex gap-3">
                  <button
                    onClick={() => {
                      setActiveDemo(activeProject.demoId);
                      setActiveProject(null);
                    }}
                    className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs shadow-lg shadow-blue-600/20 active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Play size={12} className="fill-white" />
                    <span>Instantiate Simulator</span>
                  </button>
                  <a
                    href={activeProject.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl font-bold text-xs text-center text-slate-300 hover:text-white transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Github size={12} />
                    <span>Inspect Repository</span>
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* INTERACTIVE DEMO SIMULATORS */}
      <AnimatePresence>
        {activeDemo && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              className={`bg-slate-950 border border-white/15 w-full ${
                activeDemo === 'nnPlayground' ? 'max-w-3xl' : 'max-w-xl'
              } rounded-3xl p-6 relative shadow-2xl overflow-hidden flex flex-col max-h-[90vh]`}
            >
              {/* Blue top blur */}
              <div className="absolute top-[-20%] left-[30%] w-[50%] h-[40%] bg-blue-500/10 blur-[80px] rounded-full pointer-events-none" />

              <div className="flex justify-between items-center pb-3 border-b border-white/10 mb-4">
                <div className="flex items-center gap-2">
                  {activeDemo === 'snake' ? (
                    <Gamepad2 className="text-blue-400" size={18} />
                  ) : activeDemo === 'calculator' ? (
                    <CalcIcon className="text-purple-400" size={18} />
                  ) : (
                    <Cpu className="text-emerald-400 animate-pulse" size={18} />
                  )}
                  <h3 className="font-extrabold text-base text-white">
                    {activeDemo === 'snake'
                      ? 'Computer Vision Gesture Snake'
                      : activeDemo === 'calculator'
                      ? 'Scientific Formula Calculator'
                      : 'AI & Neural Network Playground'}
                  </h3>
                </div>
                <button
                  onClick={() => {
                    setActiveDemo(null);
                    setIsSnakePlaying(false);
                  }}
                  className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* DEMO 1: COMPUTER VISION SNAKE GAME */}
              {activeDemo === 'snake' && (
                <div className="space-y-4 flex flex-col flex-grow overflow-y-auto">
                  <div className="flex justify-between items-center bg-slate-900/60 p-3 rounded-2xl border border-white/5 font-mono text-xs">
                    <div className="flex gap-4">
                      <span>Score: <b className="text-blue-400">{snakeScore}</b></span>
                      <span>High Score: <b className="text-purple-400">{snakeHighScore}</b></span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      <span className="text-slate-400 text-[10px]">Ready</span>
                    </div>
                  </div>

                  <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
                    {/* Game Board */}
                    <div className="relative bg-[#0f172a] rounded-2xl overflow-hidden border border-white/10 flex items-center justify-center">
                      <canvas
                        ref={snakeCanvasRef}
                        width={300}
                        height={300}
                        className="block cursor-pointer"
                        onClick={() => {
                          if (!isSnakePlaying && !isSnakeGameOver) resetSnakeGame();
                        }}
                      />

                      {/* Overlays */}
                      {!isSnakePlaying && !isSnakeGameOver && (
                        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center text-center p-4">
                          <Gamepad2 size={36} className="text-blue-400 mb-2 animate-bounce" />
                          <h4 className="font-bold text-sm text-white mb-1">Interactive Game Simulator</h4>
                          <p className="text-[10px] text-slate-400 max-w-xs mb-4">
                            Play using keyboard <b className="text-slate-200">Arrow Keys</b>, the controller below, or turn on OpenCV tracking simulation!
                          </p>
                          <button
                            onClick={resetSnakeGame}
                            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer"
                          >
                            Begin Game
                          </button>
                        </div>
                      )}

                      {isSnakeGameOver && (
                        <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center text-center p-4">
                          <span className="text-rose-500 font-bold font-mono text-sm tracking-wider mb-1">CRASH DETECTED</span>
                          <h4 className="font-extrabold text-lg text-white mb-1">Game Over</h4>
                          <p className="text-xs text-slate-400 mb-4">Final Score: {snakeScore}</p>
                          <button
                            onClick={resetSnakeGame}
                            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
                          >
                            Try Again
                          </button>
                        </div>
                      )}

                      {/* Mock hand gesture tracking overlay */}
                      {gestureMode && isSnakePlaying && (
                        <div className="absolute top-2 right-2 bg-black/60 border border-emerald-500/30 backdrop-blur-md rounded-lg p-1.5 text-[8px] font-mono text-emerald-400 flex flex-col gap-1 z-10 max-w-[120px]">
                          <div className="flex items-center gap-1">
                            <Camera size={10} className="animate-pulse" />
                            <span>GESTURE MODE ACTIVE</span>
                          </div>
                          <div className="h-10 bg-black/40 rounded flex items-center justify-center border border-emerald-500/15 relative overflow-hidden">
                            {/* Animated green hand points */}
                            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100">
                              <circle cx={simTargetPoint.x / 3} cy={simTargetPoint.y / 3} r="3" fill="#10b981" />
                              <line x1="50" y1="90" x2={simTargetPoint.x / 3} y2={simTargetPoint.y / 3} stroke="#10b981" strokeWidth="0.5" strokeDasharray="2 2" />
                            </svg>
                            <span className="text-[7px] text-slate-400 font-mono">Camera active</span>
                          </div>
                          <p className="truncate">{gestureSimState}</p>
                        </div>
                      )}
                    </div>

                    {/* Controls & OpenCV Simulation switch */}
                    <div className="flex-1 w-full space-y-3 font-mono text-xs">
                      <div className="bg-white/5 border border-white/5 p-3 rounded-2xl space-y-2">
                        <label className="flex items-center justify-between cursor-pointer">
                          <span className="text-[10px] text-slate-300 font-bold">Simulate OpenCV Gesture Mode</span>
                          <div className="relative">
                            <input
                              type="checkbox"
                              checked={gestureMode}
                              onChange={() => {
                                setGestureMode(!gestureMode);
                                if (!isSnakePlaying && !isSnakeGameOver) {
                                  resetSnakeGame();
                                }
                              }}
                              className="sr-only peer"
                            />
                            <div className="w-8 h-4 bg-slate-700 rounded-full peer peer-focus:ring-2 peer-focus:ring-blue-500 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-blue-600"></div>
                          </div>
                        </label>
                        <p className="text-[9px] text-slate-400 leading-relaxed">
                          When active, the snake is guided by a simulated CV hand tracking model. Turn off to play manually using Arrow Keys.
                        </p>
                      </div>

                      {/* Manual Directional Joystick for accessibility */}
                      <div className="flex flex-col items-center">
                        <span className="text-[9px] text-slate-500 uppercase tracking-widest mb-1.5 font-bold">Directional Controller</span>
                        <div className="grid grid-cols-3 gap-1.5 w-24">
                          <div />
                          <button
                            onClick={() => { if (snakeDir.y !== 1) setSnakeDir({ x: 0, y: -1 }); }}
                            className="w-7 h-7 bg-white/5 hover:bg-white/15 border border-white/10 rounded flex items-center justify-center text-slate-300 cursor-pointer active:scale-90"
                          >
                            ▲
                          </button>
                          <div />
                          <button
                            onClick={() => { if (snakeDir.x !== 1) setSnakeDir({ x: -1, y: 0 }); }}
                            className="w-7 h-7 bg-white/5 hover:bg-white/15 border border-white/10 rounded flex items-center justify-center text-slate-300 cursor-pointer active:scale-90"
                          >
                            ◀
                          </button>
                          <button
                            onClick={() => { if (snakeDir.y !== -1) setSnakeDir({ x: 0, y: 1 }); }}
                            className="w-7 h-7 bg-white/5 hover:bg-white/15 border border-white/10 rounded flex items-center justify-center text-slate-300 cursor-pointer active:scale-90"
                          >
                            ▼
                          </button>
                          <button
                            onClick={() => { if (snakeDir.x !== -1) setSnakeDir({ x: 1, y: 0 }); }}
                            className="w-7 h-7 bg-white/5 hover:bg-white/15 border border-white/10 rounded flex items-center justify-center text-slate-300 cursor-pointer active:scale-90"
                          >
                            ▶
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* DEMO 2: SCIENTIFIC CALCULATOR */}
              {activeDemo === 'calculator' && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 flex-grow overflow-y-auto">
                  {/* Left Column: Calculator Screen & Keys */}
                  <div className="md:col-span-8 space-y-3">
                    <div className="bg-slate-900 border border-white/10 rounded-2xl p-4 text-right space-y-1 relative overflow-hidden">
                      <div className="absolute top-1 left-2 text-[8px] font-mono text-purple-400">MATH ENGINE v1.2</div>
                      <div className="text-slate-400 text-xs font-mono min-h-[16px] truncate">{calcDisplay || '0'}</div>
                      <div className="text-white text-2xl font-bold font-mono tracking-tight min-h-[32px] truncate">
                        {calcResult || calcDisplay || '0'}
                      </div>
                    </div>

                    {/* Calculator Button Layout */}
                    <div className="grid grid-cols-5 gap-1.5 font-mono text-xs">
                      {/* Functions */}
                      {['sin(', 'cos(', 'tan(', 'log(', 'ln('].map((fn) => (
                        <button
                          key={fn}
                          onClick={() => handleCalcPress(fn)}
                          className="py-2.5 bg-slate-900/60 hover:bg-purple-900/30 border border-white/5 text-purple-300 rounded-xl transition-all font-semibold active:scale-95 cursor-pointer"
                        >
                          {fn.replace('(', '')}
                        </button>
                      ))}
                      {['√(', '^', 'π', 'e', '('].map((fn) => (
                        <button
                          key={fn}
                          onClick={() => handleCalcPress(fn)}
                          className="py-2.5 bg-slate-900/60 hover:bg-purple-900/30 border border-white/5 text-purple-300 rounded-xl transition-all font-semibold active:scale-95 cursor-pointer"
                        >
                          {fn}
                        </button>
                      ))}

                      {/* Number Keys & Basic Operations */}
                      {['7', '8', '9', ')', 'C'].map((char) => (
                        <button
                          key={char}
                          onClick={() => handleCalcPress(char)}
                          className={`py-3 rounded-xl font-bold transition-all active:scale-95 cursor-pointer ${
                            char === 'C' ? 'bg-rose-500/20 hover:bg-rose-500/35 text-rose-300' : 'bg-white/5 hover:bg-white/10 text-slate-100'
                          }`}
                        >
                          {char}
                        </button>
                      ))}
                      {['4', '5', '6', '*', '/'].map((char) => (
                        <button
                          key={char}
                          onClick={() => handleCalcPress(char)}
                          className={`py-3 rounded-xl font-bold transition-all active:scale-95 cursor-pointer ${
                            ['*', '/'].includes(char) ? 'bg-blue-500/10 hover:bg-blue-500/20 text-blue-300' : 'bg-white/5 hover:bg-white/10 text-slate-100'
                          }`}
                        >
                          {char}
                        </button>
                      ))}
                      {['1', '2', '3', '+', '-'].map((char) => (
                        <button
                          key={char}
                          onClick={() => handleCalcPress(char)}
                          className={`py-3 rounded-xl font-bold transition-all active:scale-95 cursor-pointer ${
                            ['+', '-'].includes(char) ? 'bg-blue-500/10 hover:bg-blue-500/20 text-blue-300' : 'bg-white/5 hover:bg-white/10 text-slate-100'
                          }`}
                        >
                          {char}
                        </button>
                      ))}
                      {['0', '.', '%', 'AC', '='].map((char) => (
                        <button
                          key={char}
                          onClick={() => handleCalcPress(char)}
                          className={`py-3 rounded-xl font-bold transition-all active:scale-95 cursor-pointer ${
                            char === '='
                              ? 'col-span-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white'
                              : char === 'AC'
                              ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300'
                              : 'bg-white/5 hover:bg-white/10 text-slate-100'
                          }`}
                        >
                          {char}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Right Column: History Log */}
                  <div className="md:col-span-4 bg-white/5 border border-white/5 p-4 rounded-2xl flex flex-col max-h-[300px]">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1 font-mono">
                      <History size={12} />
                      <span>Tape History</span>
                    </h4>
                    <div className="flex-grow overflow-y-auto space-y-1.5 pr-1 text-[11px] font-mono text-slate-300">
                      {calcHistory.length > 0 ? (
                        calcHistory.map((item, idx) => (
                          <div
                            key={idx}
                            onClick={() => {
                              const formula = item.split(' = ')[0];
                              setCalcDisplay(formula);
                              setCalcResult('');
                            }}
                            className="p-1.5 bg-black/20 hover:bg-white/5 rounded-lg border border-white/5 cursor-pointer truncate transition-colors text-right"
                          >
                            {item}
                          </div>
                        ))
                      ) : (
                        <p className="text-slate-500 italic text-[10px] text-center pt-8">No records on tape yet.</p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* DEMO 3: NEURAL NETWORK PLAYGROUND */}
              {activeDemo === 'nnPlayground' && (
                <AIPlayground onClose={() => setActiveDemo(null)} />
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FULL RESUME MODAL */}
      <AnimatePresence>
        {isResumeOpen && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-950 border border-white/15 w-full max-w-2xl rounded-3xl p-6 md:p-8 relative shadow-2xl overflow-hidden max-h-[85vh] flex flex-col"
            >
              <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[40%] bg-purple-500/10 blur-[80px] rounded-full pointer-events-none" />

              <div className="flex justify-between items-start pb-4 border-b border-white/10 mb-4 relative z-10">
                <div>
                  <h3 className="text-2xl font-extrabold text-white">Muskan Chauhan</h3>
                  <p className="text-xs text-blue-400 font-mono tracking-wider">AI App Developer | Python & Computer Vision Developer</p>
                </div>
                <button
                  onClick={() => setIsResumeOpen(false)}
                  className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Tab Selector */}
              <div className="flex border-b border-white/5 gap-2 pb-2 mb-4 overflow-x-auto relative z-10 font-mono text-[11px] no-scrollbar">
                {[
                  { id: 'education', label: 'Education', icon: GraduationCap },
                  { id: 'experience', label: 'Timeline / Projects', icon: Cpu },
                  { id: 'skills', label: 'Technical Stack', icon: Code2 },
                  { id: 'certifications', label: 'Certifications', icon: Award }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setResumeTab(tab.id as any)}
                    className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 cursor-pointer whitespace-nowrap transition-all ${
                      resumeTab === tab.id
                        ? 'bg-blue-600/25 border border-blue-500/40 text-blue-300'
                        : 'text-slate-400 hover:text-slate-200 border border-transparent'
                    }`}
                  >
                    <tab.icon size={12} />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              <div className="flex-grow overflow-y-auto space-y-4 pr-1 relative z-10 text-xs text-slate-300">
                {resumeTab === 'education' && (
                  <div className="space-y-4">
                    <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-sm text-white">B.Sc. Computer Science</h4>
                        <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full font-mono font-bold">2021 - 2024</span>
                      </div>
                      <p className="text-slate-400 text-[11px] mb-2">IGMMV Kaithal, Kurukshetra University • Haryana, India</p>
                      <p className="text-slate-300 leading-relaxed">
                        Focused core academic curriculum around Artificial Intelligence App development, Object-Oriented Programming, and database normalization structures. Graduated with a high division standing and specialized focus on hands-on project creation.
                      </p>
                    </div>

                    <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-sm text-white">Senior Secondary Education</h4>
                        <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full font-mono font-bold">2021 - 2022</span>
                      </div>
                      <p className="text-slate-400 text-[11px] mb-1">State Board Examination • Non-Medical Science stream</p>
                      <p className="text-slate-300">
                        Excellent results in Mathematics, Physics, and Computer Science foundations.
                      </p>
                    </div>
                  </div>
                )}

                {resumeTab === 'experience' && (
                  <div className="space-y-4 font-mono">
                    <div className="relative pl-6 border-l-2 border-blue-500/40 space-y-4 ml-2 py-2 text-[11px]">
                      
                      <div className="relative">
                        <span className="absolute -left-[31px] top-1.5 w-2 h-2 rounded-full bg-blue-500 ring-4 ring-blue-500/20"></span>
                        <div className="flex justify-between text-[10px] text-blue-400 font-bold mb-1">
                          <span>PERSONAL PORTFOLIO ENGINES</span>
                          <span>2024 - PRESENT</span>
                        </div>
                        <h4 className="font-bold text-white text-xs">Self-Directed Developer</h4>
                        <p className="text-slate-400 mt-1 leading-relaxed text-xs font-sans">
                          Designed and programmed custom computer vision games and mathematical utilities. Successfully mapped video frames with mathematical coordinate vectors utilizing state-of-the-art hand landmarker tracking.
                        </p>
                      </div>

                      <div className="relative">
                        <span className="absolute -left-[31px] top-1.5 w-2 h-2 rounded-full bg-purple-500 ring-4 ring-purple-500/20"></span>
                        <div className="flex justify-between text-[10px] text-purple-400 font-bold mb-1">
                          <span>GITHUB COLLABORATIONS</span>
                          <span>2023 - 2024</span>
                        </div>
                        <h4 className="font-bold text-white text-xs">Open Source Contributor</h4>
                        <p className="text-slate-400 mt-1 leading-relaxed text-xs font-sans">
                          Authored multiple functional scripts in Python and SQL databases. Maintained multiple clean code repositories showing mastery of Git commits, branching strategies, and README blueprints.
                        </p>
                      </div>

                    </div>
                  </div>
                )}

                {resumeTab === 'skills' && (
                  <div className="space-y-4 font-sans">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                        <h4 className="font-bold text-white text-xs mb-2 flex items-center gap-1">
                          <Terminal size={14} className="text-blue-400" />
                          <span>Programming Foundations</span>
                        </h4>
                        <div className="flex flex-wrap gap-1.5">
                          {['Python', 'JavaScript', 'C/C++', 'HTML5/CSS3', 'SQL (MySQL/PostgreSQL)', 'JSON'].map((s) => (
                            <span key={s} className="px-2 py-1 bg-slate-900 text-slate-300 border border-white/5 rounded-lg text-[10px] font-mono">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                        <h4 className="font-bold text-white text-xs mb-2 flex items-center gap-1">
                          <Cpu size={14} className="text-purple-400" />
                          <span>AI & Vision Libraries</span>
                        </h4>
                        <div className="flex flex-wrap gap-1.5">
                          {['OpenCV', 'MediaPipe Hand/Face Mesh', 'NumPy', 'Pandas', 'Scikit-Learn', 'Tkinter GUI'].map((s) => (
                            <span key={s} className="px-2 py-1 bg-slate-900 text-slate-300 border border-white/5 rounded-lg text-[10px] font-mono">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>

                    </div>
                  </div>
                )}

                {resumeTab === 'certifications' && (
                  <div className="space-y-3 font-sans">
                    <div className="bg-white/5 border border-white/5 p-3.5 rounded-2xl flex items-center gap-3">
                      <div className="w-9 h-9 bg-purple-500/10 rounded-xl flex items-center justify-center text-purple-400">
                        <Award size={20} />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-white">AI App Developer Specialization Course</h4>
                        <p className="text-[10px] text-slate-400">Verified Professional Training Credential</p>
                      </div>
                    </div>

                    <div className="bg-white/5 border border-white/5 p-3.5 rounded-2xl flex items-center gap-3">
                      <div className="w-9 h-9 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-400">
                        <Star size={18} />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-white">Advanced Python and OpenCV Hand Landmark Models</h4>
                        <p className="text-[10px] text-slate-400">Project-based hands-on certification</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Modal Actions */}
              <div className="pt-4 border-t border-white/10 mt-4 flex justify-between items-center relative z-10 font-mono text-[10px]">
                <span className="text-slate-500">&gt;_ End of Document</span>
                <button
                  onClick={() => {
                    const docText = `
MUSKAN CHAUHAN
AI Application Developer | Python Developer
Kaithal, Haryana, India | muskanchauhan88330044@gmail.com

EDUCATION:
- B.Sc. Computer Science (Graduated 2024)
  IGMMV Kaithal, Kurukshetra University

CORE EXPERIENCE:
- Python Automation & OOP Foundations
- Real-time Computer Vision via OpenCV & MediaPipe Landmark models
- Scientific computation with NumPy, Pandas, Scikit-Learn
`;
                    const blob = new Blob([docText], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = 'Muskan_Chauhan_Resume.txt';
                    link.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="px-4 py-2 bg-white text-black font-extrabold rounded-xl hover:bg-slate-200 transition-all flex items-center gap-1 cursor-pointer"
                >
                  <FileText size={12} />
                  <span>Download Text CV</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
