/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Project {
  id: string;
  title: string;
  tag: string;
  desc: string;
  longDesc: string;
  tech: string[];
  github: string;
  demoId: 'snake' | 'calculator' | 'nnPlayground';
}

export interface Message {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: string;
}

export interface Course {
  id: string;
  title: string;
  code: string;
  score: string;
  desc: string;
  syllabus: string[];
  sampleCodeTitle: string;
  sampleCode: string;
  sampleCodeOutput: string[];
}

export interface BlogPost {
  id: string;
  title: string;
  date: string;
  tag: string;
  readTime: string;
  summary: string;
  content: string;
  codeSnippet?: string;
}
