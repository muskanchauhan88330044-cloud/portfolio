/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { blogPosts } from '../data';
import { BlogPost } from '../types';
import { Newspaper, Clock, X, ChevronRight, Play, Terminal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function DevLogHub() {
  const [activePost, setActivePost] = useState<BlogPost | null>(null);
  const [isRunningCode, setIsRunningCode] = useState(false);
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);

  const runCodeSnippet = () => {
    if (isRunningCode) return;
    setIsRunningCode(true);
    setConsoleOutput(["muskan@portfolio:~$ python -m unittest parse_tests"]);

    let lines: string[] = [];
    if (activePost?.id === 'mp_landmarks') {
      lines = [
        "[INFO] Initializing test_finger_angles...",
        "[INPUT] landmarks = [ wrist: (0.5, 0.9), index_base: (0.5, 0.5), index_tip: (0.5, 0.3) ]",
        "[COMPUTE] tip_idx (8).y = 0.3 < base_idx (5).y = 0.5",
        "[RESULT] is_finger_extended = True",
        "----------------------------------------------------------------------",
        "Ran 1 test in 0.045s | OK"
      ];
    } else if (activePost?.id === 'cv_lag') {
      lines = [
        "[STREAM] Initializing WebCamStream on /dev/video0...",
        "[THREAD] Background thread spawned successfully.",
        "[FPS] Capture Thread: 120.4 FPS",
        "[FPS] Processing Thread: 98.2 FPS",
        "[BENCHMARK] Standard frame read: 31.4ms (Blocking)",
        "[BENCHMARK] Threaded frame read: 1.2ms (Queue Pop)",
        "[SUCCESS] Performance scaling: +820% speed efficiency!"
      ];
    } else if (activePost?.id === 'parse_trig') {
      lines = [
        "[PARSER] String tokenized: 'sin(30) * cos(60)'",
        "[CONVERT] Degree angle '30' converted to Radians: 0.5235987",
        "[CONVERT] Degree angle '60' converted to Radians: 1.0471975",
        "[EVALUATE] Math.sin(0.5235987) = 0.5000",
        "[EVALUATE] Math.cos(1.0471975) = 0.5000",
        "[SUCCESS] Computed result: 0.25000"
      ];
    }

    let idx = 0;
    const addLine = () => {
      if (idx < lines.length) {
        setConsoleOutput((prev) => [...prev, lines[idx]]);
        idx++;
        setTimeout(addLine, 200 + Math.random() * 100);
      } else {
        setIsRunningCode(false);
      }
    };
    setTimeout(addLine, 400);
  };

  return (
    <div className="flex flex-col h-full justify-between">
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Newspaper size={16} className="text-purple-400" />
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">Engineering DevLog</h3>
        </div>
        <p className="text-[10px] text-slate-500 font-mono mb-4 leading-normal">
          Bite-sized publications detailing custom model engineering and algorithms.
        </p>

        <div className="space-y-3">
          {blogPosts.map((post) => (
            <div
              key={post.id}
              onClick={() => {
                setActivePost(post);
                setConsoleOutput([]);
                setIsRunningCode(false);
              }}
              className="p-3.5 bg-slate-900/55 border border-white/5 hover:border-purple-500/30 hover:bg-slate-900/80 rounded-2xl cursor-pointer transition-all flex items-start justify-between gap-3 group"
            >
              <div className="space-y-1 max-w-[85%]">
                <span className="text-[8px] font-mono font-bold text-purple-400 bg-purple-500/10 px-1.5 py-0.5 rounded uppercase">
                  {post.tag}
                </span>
                <h4 className="font-bold text-xs text-slate-200 group-hover:text-white transition-colors pt-1">
                  {post.title}
                </h4>
                <p className="text-[10px] text-slate-400 line-clamp-1 leading-normal">
                  {post.summary}
                </p>
              </div>
              <ChevronRight size={14} className="text-slate-500 group-hover:text-purple-400 transition-colors mt-2.5 shrink-0" />
            </div>
          ))}
        </div>
      </div>

      {/* FOOTER METADATA */}
      <div className="text-[8px] font-mono text-slate-500 pt-3 border-t border-white/5 mt-4 flex justify-between">
        <span>AUTHOR: MUSKAN CHAUHAN</span>
        <span>INDEX: ACTIVE</span>
      </div>

      {/* POST DETAILS DRAWER OVERLAY */}
      <AnimatePresence>
        {activePost && (
          <div className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-end">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-slate-950 border-l border-white/10 w-full max-w-xl h-full p-6 md:p-8 overflow-y-auto relative shadow-2xl flex flex-col justify-between"
            >
              {/* Purple top blur */}
              <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[40%] bg-purple-500/5 blur-[80px] rounded-full pointer-events-none" />

              <div className="space-y-6">
                {/* Header controls */}
                <div className="flex justify-between items-center border-b border-white/10 pb-4">
                  <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono">
                    <span className="text-purple-400 uppercase font-bold bg-purple-500/10 px-2 py-0.5 rounded">
                      {activePost.tag}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={10} />
                      <span>{activePost.readTime}</span>
                    </span>
                    <span>•</span>
                    <span>{activePost.date}</span>
                  </div>
                  <button
                    onClick={() => setActivePost(null)}
                    className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
                  >
                    <X size={16} />
                  </button>
                </div>

                {/* Blog content */}
                <div className="space-y-4">
                  <h3 className="text-xl md:text-2xl font-extrabold text-white leading-tight font-sans">
                    {activePost.title}
                  </h3>
                  
                  <div className="text-xs md:text-sm text-slate-300 leading-relaxed font-sans whitespace-pre-line space-y-4">
                    {activePost.content}
                  </div>
                </div>

                {/* Code Snippet */}
                {activePost.codeSnippet && (
                  <div className="space-y-2">
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">
                      &gt;_ Snippet Implementation Record
                    </span>
                    <div className="bg-black/60 border border-white/5 rounded-2xl p-4 font-mono text-[10.5px] leading-relaxed text-blue-300 relative select-text">
                      <pre className="overflow-x-auto">{activePost.codeSnippet}</pre>
                    </div>
                  </div>
                )}

                {/* Simulation terminal */}
                {activePost.codeSnippet && (
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">
                        Interactive Snippet Executor
                      </span>
                      <button
                        onClick={runCodeSnippet}
                        disabled={isRunningCode}
                        className="px-3 py-1 bg-purple-600 hover:bg-purple-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-lg text-[9px] font-mono font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow-md shadow-purple-600/10"
                      >
                        <Play size={8} className="fill-white" />
                        <span>{isRunningCode ? 'Parsing...' : 'Execute Test'}</span>
                      </button>
                    </div>

                    <div className="bg-slate-950 border border-white/10 rounded-2xl p-3 h-28 font-mono text-[9.5px] leading-relaxed text-slate-300 flex flex-col justify-between overflow-hidden select-text">
                      <div className="overflow-y-auto flex-grow space-y-1 scrollbar-thin scrollbar-thumb-white/10 pr-1">
                        {consoleOutput.length > 0 ? (
                          consoleOutput.map((log, idx) => (
                            <p
                              key={idx}
                              className={
                                log.startsWith('muskan@portfolio:~$')
                                  ? 'text-purple-400 font-bold'
                                  : log.startsWith('[SUCCESS]') || log.includes('OK')
                                  ? 'text-emerald-400 font-bold'
                                  : log.startsWith('[COMPUTE]') || log.startsWith('[BENCHMARK]')
                                  ? 'text-blue-300'
                                  : log.startsWith('[INFO]') || log.startsWith('[STREAM]')
                                  ? 'text-slate-400'
                                  : 'text-slate-200 pl-1'
                              }
                            >
                              {log}
                            </p>
                          ))
                        ) : (
                          <p className="text-slate-500 italic text-center pt-6">Console offline. Tap "Execute Test" to observe compilation output.</p>
                        )}
                        {isRunningCode && (
                          <div className="inline-block w-1 h-2.5 bg-purple-400 animate-pulse ml-0.5" />
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Close Footer */}
              <div className="pt-4 border-t border-white/10 mt-6 flex justify-between items-center text-[9px] font-mono text-slate-500">
                <span>&copy; 2026 Muskan Chauhan</span>
                <button
                  onClick={() => setActivePost(null)}
                  className="text-slate-300 hover:text-white hover:underline cursor-pointer"
                >
                  Return to Portfolio
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
