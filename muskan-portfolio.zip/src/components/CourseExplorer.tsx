/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { courses } from '../data';
import { Course } from '../types';
import { BookOpen, GraduationCap, Play, Terminal, CheckCircle2, RotateCcw } from 'lucide-react';

export default function CourseExplorer() {
  const [activeCourseId, setActiveCourseId] = useState<string>('ds_algo');
  const [isRunning, setIsRunning] = useState<string | null>(null);
  const [terminalBuffers, setTerminalBuffers] = useState<{ [key: string]: string[] }>({});

  const activeCourse = courses.find((c) => c.id === activeCourseId) || courses[0];

  const executeCourseCode = (course: Course) => {
    if (isRunning) return;
    setIsRunning(course.id);
    setTerminalBuffers((prev) => ({
      ...prev,
      [course.id]: [`muskan@portfolio:~$ python ${course.sampleCodeTitle}`]
    }));

    let idx = 0;
    const addLine = () => {
      if (idx < course.sampleCodeOutput.length) {
        setTerminalBuffers((prev) => {
          const currentBuffer = prev[course.id] || [];
          return {
            ...prev,
            [course.id]: [...currentBuffer, course.sampleCodeOutput[idx]]
          };
        });
        idx++;
        setTimeout(addLine, 180 + Math.random() * 80);
      } else {
        setIsRunning(null);
      }
    };
    setTimeout(addLine, 300);
  };

  const clearTerminal = (courseId: string) => {
    setTerminalBuffers((prev) => ({
      ...prev,
      [courseId]: []
    }));
  };

  return (
    <div className="flex flex-col justify-between h-full relative overflow-hidden">
      <div>
        {/* Title Block */}
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 flex items-center gap-2">
              <GraduationCap size={16} className="text-blue-400" />
              <span>Academic Curriculum Explorer</span>
            </h3>
            <p className="text-[10px] text-slate-500 font-mono mt-0.5">IGMMV Kaithal, Kurukshetra University (B.Sc Computer Science)</p>
          </div>
        </div>

        {/* Layout Split: Left selection list, Right detail viewer */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-stretch mt-4">
          
          {/* Left Course Tabs Selector */}
          <div className="sm:col-span-4 flex flex-col gap-2 font-mono text-[10px]">
            {courses.map((course) => (
              <button
                key={course.id}
                onClick={() => setActiveCourseId(course.id)}
                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between gap-1 transition-all cursor-pointer ${
                  activeCourseId === course.id
                    ? 'bg-blue-600/10 border-blue-500/40 text-blue-300'
                    : 'bg-white/5 border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10'
                }`}
              >
                <div className="flex justify-between items-center w-full">
                  <span className="font-bold text-[9px] text-slate-400 tracking-tight">{course.code}</span>
                  <span className={`text-[8px] font-extrabold px-1.5 py-0.2 rounded ${
                    course.score === 'A+' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'
                  }`}>
                    Grade {course.score}
                  </span>
                </div>
                <span className="font-sans font-bold text-xs truncate leading-snug">{course.title}</span>
              </button>
            ))}
          </div>

          {/* Right Details Panel */}
          <div className="sm:col-span-8 bg-slate-900/40 border border-white/5 rounded-2xl p-4 flex flex-col justify-between gap-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-white/5 pb-2">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-100">{activeCourse.title}</h4>
                  <p className="text-[9px] text-slate-400 font-mono">Curriculum Module: {activeCourse.code}</p>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {activeCourse.desc}
              </p>

              {/* Syllabus points */}
              <div className="space-y-1">
                <span className="text-[8.5px] uppercase font-bold tracking-wider text-slate-500 font-mono">Focus Objectives:</span>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-[9.5px] text-slate-400">
                  {activeCourse.syllabus.map((s, idx) => (
                    <li key={idx} className="flex items-start gap-1">
                      <span className="text-blue-500 mt-0.5">•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Simulated Live Compiler / Run Terminal block */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <div className="flex justify-between items-center text-[9px] font-mono">
                <span className="text-slate-400 font-bold flex items-center gap-1">
                  <Terminal size={10} />
                  <span>Interactive Playground ({activeCourse.sampleCodeTitle})</span>
                </span>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => executeCourseCode(activeCourse)}
                    disabled={!!isRunning}
                    className="px-2.5 py-0.8 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <Play size={8} className="fill-white" />
                    <span>Run Script</span>
                  </button>
                  <button
                    onClick={() => clearTerminal(activeCourse.id)}
                    className="p-1 bg-white/5 border border-white/10 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                    title="Clear Buffer"
                  >
                    <RotateCcw size={8} />
                  </button>
                </div>
              </div>

              {/* Compiler Terminal Screen */}
              <div className="bg-black/80 border border-white/5 rounded-xl p-3 h-28 font-mono text-[9px] leading-relaxed text-slate-300 flex flex-col justify-between overflow-hidden select-text">
                <div className="overflow-y-auto flex-grow space-y-1 scrollbar-thin scrollbar-thumb-white/10 pr-1">
                  {(terminalBuffers[activeCourse.id] || []).length > 0 ? (
                    (terminalBuffers[activeCourse.id] || []).map((log, idx) => (
                      <p
                        key={idx}
                        className={
                          log.startsWith('muskan@portfolio:~$')
                            ? 'text-blue-400 font-bold'
                            : log.startsWith('[SUCCESS]') || log.includes('SUCCESS')
                            ? 'text-emerald-400 font-bold'
                            : log.startsWith('[COMPUTE]') || log.startsWith('[VECTOR]')
                            ? 'text-purple-300'
                            : log.startsWith('[INITIALIZE]') || log.startsWith('[SQL EXECUTE]')
                            ? 'text-slate-400'
                            : 'text-slate-200 pl-1'
                        }
                      >
                        {log}
                      </p>
                    ))
                  ) : (
                    <p className="text-slate-500 italic text-center pt-6 leading-normal">
                      Compiler offline. Click "Run Script" to instantiate computational execution threads.
                    </p>
                  )}
                  {isRunning === activeCourse.id && (
                    <div className="inline-block w-1.5 h-3 bg-blue-400 animate-pulse ml-0.5" />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
