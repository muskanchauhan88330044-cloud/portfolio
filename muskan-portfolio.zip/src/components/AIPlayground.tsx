/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Cpu, Database, Sparkles, TrendingUp, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

interface AIPlaygroundProps {
  onClose?: () => void;
}

export default function AIPlayground({ onClose }: AIPlaygroundProps) {
  // Inputs
  const [modelArch, setModelArch] = useState<'CNN' | 'MLP' | 'Linear'>('CNN');
  const [dataset, setDataset] = useState<'gestures' | 'weather' | 'grades'>('gestures');
  const [lr, setLr] = useState<number>(0.01);
  const [epochs, setEpochs] = useState<number>(30);
  const [optimizer, setOptimizer] = useState<'Adam' | 'SGD' | 'RMSprop'>('Adam');

  // Training States
  const [isTraining, setIsTraining] = useState(false);
  const [currentEpoch, setCurrentEpoch] = useState(0);
  const [lossHistory, setLossHistory] = useState<number[]>([]);
  const [accHistory, setAccHistory] = useState<number[]>([]);
  const [currentLoss, setCurrentLoss] = useState(1.2);
  const [currentAcc, setCurrentAcc] = useState(0.1);

  // Finished States
  const [isFinished, setIsFinished] = useState(false);
  const [metrics, setMetrics] = useState({
    accuracy: 0,
    loss: 0,
    valAccuracy: 0,
    f1Score: 0,
    precision: 0,
    recall: 0,
  });
  const [confusionMatrix, setConfusionMatrix] = useState<number[][]>([
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0]
  ]);

  const trainingRef = useRef<NodeJS.Timeout | null>(null);

  const startTraining = () => {
    if (isTraining) return;

    setIsTraining(true);
    setIsFinished(false);
    setCurrentEpoch(0);
    setLossHistory([]);
    setAccHistory([]);

    let startLoss = 1.0;
    if (modelArch === 'Linear') startLoss = 1.4;
    if (modelArch === 'MLP') startLoss = 1.2;

    let targetMinLoss = 0.05;
    if (lr === 0.001) targetMinLoss = 0.35; // slower learning
    if (lr === 0.1) targetMinLoss = 0.15;  // high lr might overshoot
    if (optimizer === 'SGD') targetMinLoss += 0.1;

    let targetMaxAcc = 0.99;
    if (lr === 0.001) targetMaxAcc = 0.72;
    if (modelArch === 'Linear') targetMaxAcc = 0.82;
    if (optimizer === 'SGD') targetMaxAcc -= 0.08;

    let epoch = 0;
    const intervalTime = Math.max(80, 2000 / epochs); // target total ~2-3 seconds

    const runEpoch = () => {
      epoch++;
      setCurrentEpoch(epoch);

      // Math formulas to simulate convergence based on parameters
      const progress = epoch / epochs;
      
      // Calculate loss with simulated convergence physics
      let convergenceRate = 3.0;
      if (optimizer === 'Adam') convergenceRate = 4.2;
      if (optimizer === 'RMSprop') convergenceRate = 3.5;
      if (lr === 0.001) convergenceRate = 1.2;
      if (lr === 0.1) convergenceRate = 5.0;

      let noise = (Math.random() - 0.5) * 0.05;
      if (lr === 0.1) noise *= 3.0; // high LR has high noise
      if (optimizer === 'SGD') noise *= 2.0;

      const baseLoss = startLoss * Math.exp(-convergenceRate * progress);
      const computedLoss = Math.max(targetMinLoss, baseLoss + noise);
      const lossVal = parseFloat(computedLoss.toFixed(4));

      // Calculate accuracy
      const baseAcc = 0.1 + (targetMaxAcc - 0.1) * (1 - Math.exp(-convergenceRate * progress));
      const computedAcc = Math.min(targetMaxAcc, baseAcc + noise * 0.3);
      const accVal = parseFloat(computedAcc.toFixed(4));

      setCurrentLoss(lossVal);
      setCurrentAcc(accVal);

      setLossHistory((prev) => [...prev, lossVal]);
      setAccHistory((prev) => [...prev, accVal]);

      if (epoch < epochs) {
        trainingRef.current = setTimeout(runEpoch, intervalTime);
      } else {
        // Complete training
        setIsTraining(false);
        setIsFinished(true);

        const finalAcc = accVal;
        const finalLoss = lossVal;
        const valAcc = parseFloat(Math.min(finalAcc - 0.012 - Math.random() * 0.02, 0.995).toFixed(4));
        const finalPrecision = parseFloat((finalAcc + 0.003 + Math.random() * 0.004).toFixed(4));
        const finalRecall = parseFloat((finalAcc - 0.005 - Math.random() * 0.004).toFixed(4));
        const finalF1 = parseFloat(((2 * finalPrecision * finalRecall) / (finalPrecision + finalRecall)).toFixed(4));

        setMetrics({
          accuracy: finalAcc,
          loss: finalLoss,
          valAccuracy: valAcc,
          f1Score: finalF1,
          precision: finalPrecision,
          recall: finalRecall,
        });

        // Generate custom confusion matrix
        let samples = 1000;
        if (dataset === 'weather') samples = 2500;
        if (dataset === 'grades') samples = 400;

        const p1 = Math.round(samples * 0.33 * finalAcc);
        const p2 = Math.round(samples * 0.33 * finalAcc * 0.98);
        const p3 = Math.round(samples * 0.34 * finalAcc * 0.99);

        const diff1 = Math.round((samples * 0.33 - p1) / 2);
        const diff2 = Math.round((samples * 0.33 - p2) / 2);
        const diff3 = Math.round((samples * 0.34 - p3) / 2);

        setConfusionMatrix([
          [p1, diff1, diff1],
          [diff2, p2, diff2],
          [diff3, diff3, p3]
        ]);
      }
    };

    trainingRef.current = setTimeout(runEpoch, intervalTime);
  };

  const resetAll = () => {
    if (trainingRef.current) clearTimeout(trainingRef.current);
    setIsTraining(false);
    setIsFinished(false);
    setCurrentEpoch(0);
    setLossHistory([]);
    setAccHistory([]);
    setCurrentLoss(1.2);
    setCurrentAcc(0.1);
  };

  useEffect(() => {
    return () => {
      if (trainingRef.current) clearTimeout(trainingRef.current);
    };
  }, []);

  // Compute SVG line path coordinates
  const getSvgPath = (data: number[], minVal: number, maxVal: number, isLoss: boolean) => {
    if (data.length < 2) return '';
    const width = 280;
    const height = 110;
    const padX = 10;
    const padY = 10;

    const points = data.map((val, idx) => {
      const x = padX + (idx / (epochs - 1)) * (width - 2 * padX);
      // invert Y coordinate for loss/accuracy scaling
      let y = 0;
      if (isLoss) {
        // scale loss from 0.0 to 1.5
        const norm = (val - 0) / (1.5 - 0);
        y = height - padY - norm * (height - 2 * padY);
      } else {
        // scale accuracy from 0.0 to 1.0
        const norm = (val - 0) / (1.0 - 0);
        y = height - padY - norm * (height - 2 * padY);
      }
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    return `M ${points.join(' L ')}`;
  };

  return (
    <div className="space-y-4 flex flex-col flex-grow overflow-y-auto">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-stretch">
        
        {/* Configurations Controls */}
        <div className="md:col-span-5 bg-slate-900/40 border border-white/5 p-4 rounded-2xl flex flex-col justify-between gap-3 text-[11px] font-mono leading-normal">
          <div className="space-y-2.5">
            <span className="text-blue-400 font-bold tracking-wide uppercase text-[8px] flex items-center gap-1">
              <Cpu size={12} />
              <span>Hyperparameter Knobs</span>
            </span>

            {/* Model Architecture Selection */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[10px] font-semibold">Model Architecture:</label>
              <div className="grid grid-cols-3 gap-1 bg-black/40 p-0.5 rounded-lg border border-white/5">
                {(['CNN', 'MLP', 'Linear'] as const).map((arch) => (
                  <button
                    key={arch}
                    disabled={isTraining}
                    onClick={() => setModelArch(arch)}
                    className={`py-1 rounded-md text-[9px] font-bold cursor-pointer transition-all ${
                      modelArch === arch ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {arch === 'CNN' ? 'ConvNet' : arch === 'MLP' ? 'Dense' : 'Linear'}
                  </button>
                ))}
              </div>
            </div>

            {/* Dataset Selection */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[10px] font-semibold">Dataset Feed:</label>
              <div className="grid grid-cols-3 gap-1 bg-black/40 p-0.5 rounded-lg border border-white/5">
                {(['gestures', 'weather', 'grades'] as const).map((ds) => (
                  <button
                    key={ds}
                    disabled={isTraining}
                    onClick={() => setDataset(ds)}
                    className={`py-1 rounded-md text-[9px] font-bold cursor-pointer transition-all ${
                      dataset === ds ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {ds === 'gestures' ? 'Gestures' : ds === 'weather' ? 'Weather' : 'Grades'}
                  </button>
                ))}
              </div>
            </div>

            {/* Learning Rate Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-semibold">
                <span className="text-slate-400">Learning Rate (α):</span>
                <span className="text-blue-300 font-bold">{lr}</span>
              </div>
              <div className="flex gap-1.5">
                {[0.001, 0.01, 0.1].map((rate) => (
                  <button
                    key={rate}
                    disabled={isTraining}
                    onClick={() => setLr(rate)}
                    className={`flex-1 py-1 bg-slate-950 border rounded-lg text-[9px] font-bold cursor-pointer ${
                      lr === rate ? 'border-blue-500 text-blue-300 bg-blue-500/10' : 'border-white/5 text-slate-400'
                    }`}
                  >
                    {rate}
                  </button>
                ))}
              </div>
            </div>

            {/* Optimizer */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[10px] font-semibold">Optimizer Algorithm:</label>
              <div className="grid grid-cols-3 gap-1 bg-black/40 p-0.5 rounded-lg border border-white/5">
                {(['Adam', 'SGD', 'RMSprop'] as const).map((opt) => (
                  <button
                    key={opt}
                    disabled={isTraining}
                    onClick={() => setOptimizer(opt)}
                    className={`py-1 rounded-md text-[9px] font-bold cursor-pointer transition-all ${
                      optimizer === opt ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Total Epochs */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-semibold">
                <span className="text-slate-400">Training Epochs:</span>
                <span className="text-blue-300 font-bold">{epochs}</span>
              </div>
              <div className="flex gap-1.5">
                {[10, 30, 50].map((ep) => (
                  <button
                    key={ep}
                    disabled={isTraining}
                    onClick={() => setEpochs(ep)}
                    className={`flex-1 py-1 bg-slate-950 border rounded-lg text-[9px] font-bold cursor-pointer ${
                      epochs === ep ? 'border-blue-500 text-blue-300 bg-blue-500/10' : 'border-white/5 text-slate-400'
                    }`}
                  >
                    {ep} ep
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex gap-2 pt-2 border-t border-white/5 mt-1">
            <button
              disabled={isTraining}
              onClick={startTraining}
              className="flex-grow py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 text-white rounded-xl font-bold font-sans text-xs flex items-center justify-center gap-1.5 transition-all shadow active:scale-95 cursor-pointer"
            >
              <Play size={12} className="fill-white" />
              <span>{isTraining ? 'Training...' : 'Fit Model'}</span>
            </button>
            <button
              onClick={resetAll}
              className="px-3 bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl transition-all border border-white/10 cursor-pointer flex items-center justify-center"
              title="Reset Sandbox"
            >
              <RotateCcw size={12} />
            </button>
          </div>
        </div>

        {/* Live Vector Performance Monitor */}
        <div className="md:col-span-7 bg-slate-950/80 border border-white/10 rounded-2xl p-4 flex flex-col justify-between gap-3 relative overflow-hidden">
          
          {/* Header metadata */}
          <div className="flex justify-between items-center text-[9px] font-mono">
            <div className="flex items-center gap-1 text-emerald-400">
              <Database size={10} />
              <span>INGRESS: {dataset.toUpperCase()}_DB</span>
            </div>
            <div className="text-slate-400">
              Epoch: <b className="text-white">{currentEpoch}</b> / {epochs}
            </div>
          </div>

          {/* Graphical Plots Area */}
          <div className="relative bg-black/60 border border-white/5 rounded-xl p-2.5 h-36 flex flex-col justify-end">
            
            {lossHistory.length > 1 ? (
              <svg className="w-full h-full max-h-[120px]" viewBox="0 0 280 110">
                {/* Accuracy Curve (Green) */}
                <path
                  d={getSvgPath(accHistory, 0, 1.0, false)}
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="1.5"
                  className="transition-all duration-100"
                />
                
                {/* Loss Curve (Rose) */}
                <path
                  d={getSvgPath(lossHistory, 0, 1.5, true)}
                  fill="none"
                  stroke="#f43f5e"
                  strokeWidth="1.5"
                  strokeDasharray="1 1"
                  className="transition-all duration-100"
                />
              </svg>
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-[10px] text-slate-500 font-mono">
                <TrendingUp size={20} className="text-slate-600 mb-1 animate-pulse" />
                <span>Ready to stream loss/accuracy gradients.</span>
                <span>Click "Fit Model" to optimize parameters.</span>
              </div>
            )}

            {/* Small Legend Overlay */}
            {lossHistory.length > 0 && (
              <div className="absolute bottom-2 left-2 flex gap-3 text-[7.5px] font-mono bg-black/80 px-2 py-0.5 rounded border border-white/5">
                <span className="flex items-center gap-1 text-emerald-400 font-bold">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                  <span>Accuracy: {currentAcc.toFixed(3)}</span>
                </span>
                <span className="flex items-center gap-1 text-rose-400 font-bold">
                  <span className="w-1.5 h-1.5 bg-rose-500 rounded-full"></span>
                  <span>Loss: {currentLoss.toFixed(3)}</span>
                </span>
              </div>
            )}
          </div>

          {/* Running Terminal log / parameters review */}
          <div className="bg-black/80 rounded-xl p-3 font-mono text-[9px] leading-relaxed text-slate-300 space-y-1 select-text">
            {isTraining ? (
              <div className="space-y-0.5 animate-pulse">
                <p className="text-blue-400">--- LIVE CONVERGENCE TRAJECTORY ---</p>
                <p className="text-slate-400">&gt; Epoch {currentEpoch}: loss = {currentLoss} | accuracy = {currentAcc}</p>
                <p className="text-slate-500">&gt; Backpropagating errors with {optimizer} optimizer... </p>
              </div>
            ) : isFinished ? (
              <div className="space-y-0.5">
                <div className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 size={10} />
                  <span>[CONVERGED] Optimal weight matrix exported successfully!</span>
                </div>
                <div className="grid grid-cols-2 gap-x-4 text-[8.5px] text-slate-400 mt-1">
                  <p>Final loss: <b className="text-slate-200">{metrics.loss}</b></p>
                  <p>Test Accuracy: <b className="text-emerald-400">{(metrics.accuracy * 100).toFixed(1)}%</b></p>
                  <p>Validation Acc: <b className="text-blue-400">{(metrics.valAccuracy * 100).toFixed(1)}%</b></p>
                  <p>Model F1-Score: <b className="text-purple-400">{metrics.f1Score}</b></p>
                </div>
              </div>
            ) : (
              <div className="text-slate-500">
                <p>&gt;_ System state: IDLE</p>
                <p>&gt;_ Parameters configured: lr={lr}, epochs={epochs}, optimizer={optimizer}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Finished State Summary & Heatmap Matrix */}
      {isFinished && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900/40 border border-white/5 p-4 rounded-2xl relative overflow-hidden font-mono text-[10px]"
        >
          <div className="absolute top-0 right-0 p-2 text-purple-400 flex items-center gap-0.5">
            <Sparkles size={10} className="animate-spin" />
            <span className="text-[8px] font-bold uppercase tracking-wider">Metrics Active</span>
          </div>

          <h4 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-1">
            <span>Confusion Matrix & Class Evaluation</span>
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* 3x3 Heatmap Grid */}
            <div className="md:col-span-5 flex flex-col">
              <span className="text-[8px] text-slate-500 uppercase font-bold mb-1 block">Predicted vs. Actual Target Class:</span>
              <div className="bg-black/60 rounded-xl p-2.5 border border-white/5 space-y-1.5 flex flex-col justify-center items-center text-center">
                
                {/* Labels row */}
                <div className="grid grid-cols-4 gap-1.5 w-full text-[8px] text-slate-500 font-bold">
                  <div />
                  <div>Class A</div>
                  <div>Class B</div>
                  <div>Class C</div>
                </div>

                {/* Matrix Rows */}
                {confusionMatrix.map((row, rIdx) => (
                  <div key={rIdx} className="grid grid-cols-4 gap-1.5 w-full items-center text-[9px]">
                    <div className="text-[8px] text-slate-500 font-bold text-right pr-1">Class {String.fromCharCode(65 + rIdx)}</div>
                    {row.map((val, cIdx) => {
                      const isDiagonal = rIdx === cIdx;
                      return (
                        <div
                          key={cIdx}
                          className={`py-1.5 rounded-lg font-bold border transition-all ${
                            isDiagonal
                              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                              : 'bg-rose-500/5 border-rose-500/10 text-slate-500'
                          }`}
                        >
                          {val}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>

            {/* Metrics analysis */}
            <div className="md:col-span-7 flex flex-col justify-between">
              <div className="space-y-1.5 text-slate-300 text-[11px] leading-relaxed">
                <p>
                  <span className="text-slate-500 font-bold">Precision:</span> <b className="text-slate-200">{(metrics.precision * 100).toFixed(1)}%</b> • Indicates that {Math.round(metrics.precision * 100)}% of predictions for chosen category are true labels.
                </p>
                <p>
                  <span className="text-slate-500 font-bold">Recall (Sensitivity):</span> <b className="text-slate-200">{(metrics.recall * 100).toFixed(1)}%</b> • Core sensor model correctly captured {Math.round(metrics.recall * 100)}% of all class instances.
                </p>
                <p>
                  <span className="text-slate-500 font-bold">F1 Harmonic Score:</span> <b className="text-purple-400">{metrics.f1Score}</b> • Represents excellent stability between Precision and Recall parameters.
                </p>
              </div>

              <div className="text-[8.5px] text-slate-500 mt-2 italic leading-normal pt-1.5 border-t border-white/5">
                * Simulated on {modelArch} architecture over IGMMV Kaithal, Kurukshetra University test sets.
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
